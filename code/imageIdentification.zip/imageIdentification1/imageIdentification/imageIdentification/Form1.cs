﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace imageIdentification
{
    public partial class Form1 : Form
    {
        public static PictureBox original_image = new PictureBox();

        public Form1()
        {
            InitializeComponent();

            all_btn_click_change();//所有按钮的按下变色时间
            all_comboBox_fill();//所有下拉框的东西
        }

        private void all_comboBox_fill()
        {
            //初始化颜色通道的下拉框
            string[] color_channel = new[] { "红", "绿", "蓝" };
            comboBox_colorCollect.DataSource = color_channel;
            comboBox_colorCollect.DropDownStyle = ComboBoxStyle.DropDownList;
            //DropDown（默认）下拉框可编辑。②Simple：简单组合框。③DropDownList：下拉框不可编辑

            //初始化图像平滑的下拉框
            string[] image_smooth = new[] { "四邻域平均", "八邻域平均", "最大值滤波",
                "最小值滤波", "中值滤波","自适应中值滤波","修正平均滤波","高斯滤波" };
            comboBox_smoothCollect.DataSource = image_smooth;
            comboBox_smoothCollect.DropDownStyle = ComboBoxStyle.DropDownList;

            //初始化图像锐化的下拉框
            string[] image_sharpening = new[] { "水平垂直差分法", "soble算子", "robert算子",
                "prewitt算子", "Laplacian算子","robinson算子","kirsch算子" };
            comboBox_sharpeningCollect.DataSource = image_sharpening;
            comboBox_sharpeningCollect.DropDownStyle = ComboBoxStyle.DropDownList;

            //初始化 二值 图像变换的下拉框
            string[] binary_change = new[] { "膨胀", "腐蚀", "开启", "闭合", "边缘提取", "顶帽运算", "黑帽运算" };
            comboBox_binaryChangeCollect.DataSource = binary_change;
            comboBox_binaryChangeCollect.DropDownStyle = ComboBoxStyle.DropDownList;

            //初始化 SE模板 的下拉框
            string[] SE_change = new[] { "正方形", "十字型", "椭圆型" };
            comboBox_structureElementSelect.DataSource = SE_change;
            comboBox_structureElementSelect.DropDownStyle = ComboBoxStyle.DropDownList;


            //初始化 SE模板 的下拉框
            string[] picCategory_change = new[] { "二值图", "彩色图", "灰度图" };
            comboBox_picCategory.DataSource = picCategory_change;
            comboBox_picCategory.DropDownStyle = ComboBoxStyle.DropDownList;

            //初始化 伪彩色处理的 的下拉框
            string[] WeiCaiSeCollect = new[] { "彩虹色带映射", "铁红色带映射",
                "灰度级-彩色变换法","强度分层法" };
            comboBox_WeiCaiSeCollect.DataSource = WeiCaiSeCollect;
            comboBox_WeiCaiSeCollect.DropDownStyle = ComboBoxStyle.DropDownList;


        }
        private void all_btn_click_change()
        {
            //打开图片的按钮按下恢复事件
            this.btn_open.MouseDown += new MouseEventHandler(btn_open_MouseDown);
            this.btn_open.MouseUp += new MouseEventHandler(btn_open_MouseUp);

            //保存图片的按钮按下恢复事件
            this.btn_save.MouseDown += new MouseEventHandler(btn_save_MouseDown);
            this.btn_save.MouseUp += new MouseEventHandler(btn_save_MouseUp);

            //图片灰度化的按钮按下恢复事件
            this.btn_gray.MouseDown += new MouseEventHandler(btn_gray_MouseDown);
            this.btn_gray.MouseUp += new MouseEventHandler(btn_gray_MouseUp);

            //图片恢复的按钮按下恢复事件
            this.btn_restore.MouseDown += new MouseEventHandler(btn_restore_MouseDown);
            this.btn_restore.MouseUp += new MouseEventHandler(btn_restore_MouseUp);

            //亮度调节的确认按钮按下恢复事件
            this.btnBrightnessadjust.MouseDown += new MouseEventHandler(btnBrightnessadjust_MouseDown);
            this.btnBrightnessadjust.MouseUp += new MouseEventHandler(btnBrightnessadjust_MouseUp);

            //图像对比度调节的按钮按下恢复事件
            this.btnContrastAdjust.MouseDown += new MouseEventHandler(btnContrastAdjust_MouseDown);
            this.btnContrastAdjust.MouseUp += new MouseEventHandler(btnContrastAdjust_MouseUp);

            //图像二值化调节的按钮按下恢复事件
            this.btnBinaryadjust.MouseDown += new MouseEventHandler(btnBinaryadjust_MouseDown);
            this.btnBinaryadjust.MouseUp += new MouseEventHandler(btnBinaryadjust_MouseUp);

            //颜色通道选取的按钮按下恢复事件
            this.btnColoradjust.MouseDown += new MouseEventHandler(btnColoradjust_MouseDown);
            this.btnColoradjust.MouseUp += new MouseEventHandler(btnColoradjust_MouseUp);

            //图像平滑
            this.btnSmoothadjust.MouseDown += new MouseEventHandler(btnSmoothadjust_MouseDown);
            this.btnSmoothadjust.MouseUp += new MouseEventHandler(btnSmoothadjust_MouseUp);

            //图像锐化
            this.btnSharpeningadjust.MouseDown += new MouseEventHandler(btnSharpeningadjust_MouseDown);
            this.btnSharpeningadjust.MouseUp += new MouseEventHandler(btnSharpeningadjust_MouseUp);

            //图像二值化 处理 的按钮按下恢复事件
            this.btnBinaryChangeadjust.MouseDown += new MouseEventHandler(btnBinaryChangeadjust_MouseDown);
            this.btnBinaryChangeadjust.MouseUp += new MouseEventHandler(btnBinaryChangeadjust_MouseUp);

            //图像加高斯噪声 处理 的按钮按下恢复事件
            this.btnGaussianadjust.MouseDown += new MouseEventHandler(btnGaussianadjust_MouseDown);
            this.btnGaussianadjust.MouseUp += new MouseEventHandler(btnGaussianadjust_MouseUp);

            //图像加 椒盐噪声 处理 的按钮按下恢复事件
            this.btnImpulseadjust.MouseDown += new MouseEventHandler(btnImpulseadjust_MouseDown);
            this.btnImpulseadjust.MouseUp += new MouseEventHandler(btnImpulseadjust_MouseUp);

            //图像放大  的按钮按下恢复事件
            this.btn_magnify.MouseDown += new MouseEventHandler(btn_magnify_MouseDown);
            this.btn_magnify.MouseUp += new MouseEventHandler(btn_magnify_MouseUp);

            //图像旋转  的按钮按下恢复事件
            this.btnSpinadjust.MouseDown += new MouseEventHandler(btnSpinadjust_MouseDown);
            this.btnSpinadjust.MouseUp += new MouseEventHandler(btnSpinadjust_MouseUp);

            //图像添加 随机噪声 的按钮按下恢复事件
            this.btnRandomadjust.MouseDown += new MouseEventHandler(btnRandomadjust_MouseDown);
            this.btnRandomadjust.MouseUp += new MouseEventHandler(btnRandomadjust_MouseUp);

            //图像 伪彩色处理 的按钮按下恢复事件
            this.btnWeiCaiSe.MouseDown += new MouseEventHandler(btnWeiCaiSe_MouseDown);
            this.btnWeiCaiSe.MouseUp += new MouseEventHandler(btnWeiCaiSe_MouseUp);


        }

        //判断picturebox是否有图片
        public bool judge_pb_img_exit()
        {
            if (pictureBox_show.Image == null)//判断图片框是否有图片，如果无图片，则给出错误信息
            {
                MessageBox.Show("错误，没有导入图片");
                return false;
            }
            return true;
        }


        //打开图片按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_open_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();//打开文件夹啊
            //如果选择了某个文件，并点击了OK后，那么将选择的文件返回
            if (openFileDialog.ShowDialog() == DialogResult.OK && (openFileDialog.FileName != ""))
            {
                pictureBox_show.ImageLocation = openFileDialog.FileName;//;//将图像文件赋给图片框“pictureBox1”
                pictureBox_show.BackgroundImageLayout = ImageLayout.Stretch;
                pictureBox_show.SizeMode = PictureBoxSizeMode.StretchImage;//PictureBox 中的图像被拉伸或收缩，以适合 PictureBox 的大小。(充满PictureBox)

                //original_image.Image = Image.FromFile(openFileDialog.FileName);
                original_image.Image = System.Drawing.Image.FromFile(openFileDialog.FileName);
                original_image.Width = original_image.Image.Width;
                original_image.Height = original_image.Image.Height;
            }

            openFileDialog.Dispose();
        }
        private void btn_open_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_open.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_open_press.png");
        }
        private void btn_open_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_open.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_open.png");
        }


        //保存图片的按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void button1_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK) //如果选择了某个文件夹并取了一个合法的文件名，并点击了“OK”
            {
                pictureBox_show.Image.Save(saveFileDialog1.FileName); //保存文件到指定的文件夹
            }
        }
        private void btn_save_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_save.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_save_press.png");
        }
        private void btn_save_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_save.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_save.png");
        }



        //图片灰度化的按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_gray_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            Bitmap bt = new Bitmap(original_image.Image);
            Bitmap bt1 = new Bitmap(pictureBox_show.Image); //定义并初始化两个位图对象
            Color color = new Color();//定义一个颜色对象
            for (int i = 0; i < bt.Width; i++)
            {
                for (int j = 0; j < bt.Height; j++)
                {
                    color = bt.GetPixel(i, j); //遍历整张图像，获取每个像素的色彩信息
                    //根据GRB的不同的权值计算每个像素点的亮度，利用该亮度作为灰度图像中每个像素的灰度值
                    int n = (int)((color.G * 59 + color.R * 30 + color.B * 11) / 100);
                    bt1.SetPixel(i, j, Color.FromArgb(n, n, n)); //给该像素的每种色彩分量均赋予相同的灰度值，完成灰度图像的转换
                }
            }
            pictureBox_show.Refresh();//刷新图片框
            pictureBox_show.Image = bt1;

        }
        private void btn_gray_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_gray.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_gray_press.png");
        }
        private void btn_gray_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_gray.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_gray.png");
        }



        //图片恢复按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_restore_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            pictureBox_show.Image = original_image.Image;
        }
        private void btn_restore_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_restore.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_restore_press.png");
        }
        private void btn_restore_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_restore.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_restore.png");
        }




        //亮度调节的确认按钮的点击事件？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnBrightnessadjust_Click(object sender, EventArgs e)
        {//亮度调节就是修改像素分量的值使得其根据调节值改变图像的亮度
            if (!judge_pb_img_exit()) return;

            int value;
            //为0表示没有进行操作
            if (textBox_showBrightness.Text.Equals(""))
            {
                return;
            }
            else
            {
                value = int.Parse(textBox_showBrightness.Text); /*将文本框中的数字读出用于作为亮度改变的依据，该值
            来源于滑杆的值，在文本框中其属性为文本类型，因此需要转换为整数类型*/
            }

            Bitmap bt = new Bitmap(original_image.Image); //声明两个位图对象并用图片框中的图片初始化它
            Bitmap bt1 = new Bitmap(original_image.Image);
            int r, g, b; //定义三个整形对象用于存储红、绿、蓝三色的信息
            //逐个扫描原始图片的像素
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    //获取位于（i,j）坐标的像素然后提取RGB分量
                    Color color = bt.GetPixel(i, j);
                    r = color.R;
                    g = color.G;
                    b = color.B;
                    //对RGB分量进行增加或删除，增加量为滑杆滑动的量
                    r += value;
                    g += value;
                    b += value;
                    //判断各颜色分量的值是否超过各分量允许的范围，如果大于255则只能等于255
                    if (r > 255) r = 255; if (r < 0) r = 0;//如果小于0则只能等于0
                    if (g > 255) g = 255; if (g < 0) g = 0;
                    if (b > 255) b = 255; if (b < 0) b = 0;
                    Color c1 = Color.FromArgb(r, g, b);//利用调整后的值生成新的颜色对象
                    bt1.SetPixel(i, j, c1);//把新的颜色c1赋值给bt1位图对象在坐标为(i,j)的像素
                }
                //每处理一列就进行刷新这样可以动态的显示效果
                pictureBox_show.Refresh();
                //把bt1位图对象赋值给图像框
                pictureBox_show.Image = bt1;
            }
        }
        private void btnBrightnessadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnBrightnessadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnBrightnessadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnBrightnessadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }
        //亮度调节滑块？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void trackBar_brightness_Scroll(object sender, EventArgs e)
        {
            //拉动亮度滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为亮度的调节
            textBox_showBrightness.Text = trackBar_brightness.Value.ToString();

        }






        //图像对比度调节按钮的确认点击事件？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnContrastAdjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            int degree = int.Parse(textBox_showContrast.Text); //获取对比度值
            int r, g, b;//声明3个变量用于保存RGB三个分量
            //声明两个位图对象并用图片框中的图片初始化它
            Bitmap bt = new Bitmap(original_image.Image);
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            //逐个扫描原始图片的像素
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    //获取位于(i,j)坐标的像素然后提取RGB分量
                    Color c = bt.GetPixel(i, j);
                    r = c.R;
                    g = c.G;
                    b = c.B;
                    //对RGB分量进行变换
                    int rg = (Math.Abs(127 - r) * degree) / 255;
                    int gg = (Math.Abs(127 - g) * degree) / 255;
                    int bg = (Math.Abs(127 - b) * degree) / 255;
                    //这个判断的作用是使得颜色对比度更加明显也就是亮度更亮暗的更暗
                    if (r > 127) r = r + rg;
                    else r = r - rg;
                    if (g > 127) g = g + gg;
                    else g = g - gg;
                    if (b > 127) b = b + bg;
                    else b = b - bg;
                    //判断三分量是否超过了取值范围
                    if (r > 255) r = 255;
                    if (r < 0) r = 0;
                    if (g > 255) g = 255;
                    if (g < 0) g = 0;
                    if (b > 255) b = 255;
                    if (b < 0) b = 0;
                    Color c1 = Color.FromArgb(r, g, b);
                    //把新的像素赋值bt1位图对象在坐标为(i,j)的像素
                    bt1.SetPixel(i, j, c1);
                }
                //每处理一列就进行刷新这样可以动态的显示效果
                pictureBox_show.Refresh();
                //把bt1位图对象赋值给图像框
                pictureBox_show.Image = bt1;
            }
        }
        private void trackBar_contrast_Scroll(object sender, EventArgs e)
        {
            //拉动对比度滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为对比度的调节值
            textBox_showContrast.Text = trackBar_contrast.Value.ToString();
        }
        private void btnContrastAdjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnContrastAdjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnContrastAdjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnContrastAdjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }




        //点击按钮打开HSI调节？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_hsi_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;

            //声明两个位图对象并用图片框中的图片初始化它
            Bitmap bt1 = new Bitmap(original_image.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            Color color = new Color();
            //新建一个小窗体用于调节各分量
            Form_HSI form_HSI = new Form_HSI();
            form_HSI.ShowDialog();
            int H = form_HSI.valueH;
            int S = form_HSI.valueS;
            int I = form_HSI.valueI; //在调节窗体上生成三个滑动条，分别用于调整色调、饱和度和强度
            if (H == 0 && S == 0 && I == 0) return;
            int Red, Green, Blue;
            double Hudu = Math.PI / 180;
            if (H >= 0 && H <= 120)
            {
                for (int i = 0; i < bt1.Width; i++)
                {
                    for (int j = 0; j < bt1.Height; j++)
                    {
                        int R, G, B;
                        color = bt1.GetPixel(i, j);
                        R = color.R;
                        G = color.G;
                        B = color.B;
                        Blue = B + I * (I - S); //根据转换公式，在原各RGB分量基础上加上调整的值
                        Red = (int)(R + I * (1 + (S * Math.Cos(H * Hudu) / (Math.Cos((60 - H) *
                       Hudu)))));
                        Green = G + 3 * I - (Blue + Red);
                        if (Red > 255) Red = 255; //判断是否超出各分量允许的范围，如果大于255则只能等于255
                        if (Red < 0) Red = 0; //如果小于0则只能等于0
                        if (Green > 255) Green = 255;
                        if (Green < 0) Green = 0;
                        if (Blue > 255) Blue = 255;
                        if (Blue < 0) Blue = 0;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox_show.Refresh();
                    pictureBox_show.Image = bt2;
                }
            }
            if (H > 120 && H <= 240)
            {
                for (int i = 0; i < bt1.Width; i++)
                {
                    for (int j = 0; j < bt1.Height; j++)
                    {
                        int R, G, B;
                        color = bt1.GetPixel(i, j);
                        R = color.R;
                        G = color.G;
                        B = color.B;
                        Red = R + I * (I - S); //根据转换公式，在原各RGB分量基础上加上调整的值
                        Green = (int)(G + I * (1 + (S * Math.Cos((H - 120) * Hudu) / (Math.Cos((180 -
                       H) * Hudu)))));
                        Blue = B + 3 * I - (Green + Red);
                        if (Red > 255) Red = 255; //判断是否超出各分量允许的范围，如果大于255则只能等于255
                        if (Red < 0) Red = 0; //如果小于0则只能等于0
                        if (Green > 255) Green = 255;
                        if (Green < 0) Green = 0;
                        if (Blue > 255) Blue = 255;
                        if (Blue < 0) Blue = 0;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox_show.Refresh();
                    pictureBox_show.Image = bt2;
                }
            }
            if (H > 240 && H <= 360)
            {
                for (int i = 0; i < bt1.Width; i++)
                {
                    for (int j = 0; j < bt1.Height; j++)
                    {
                        int R, G, B;
                        color = bt1.GetPixel(i, j);
                        R = color.R;
                        G = color.G;
                        B = color.B;
                        Green = G + I * (I - S); //根据转换公式，在原各RGB分量基础上加上调整的值
                        Blue = (int)(B + I * (1 + (S * Math.Cos((H - 120) * Hudu) / (Math.Cos((300 - H)
                       * Hudu)))));
                        Red = R + 3 * I - (Blue + Green);
                        if (Red > 255) Red = 255; //判断是否超出各分量允许的范围，如果大于255则只能等于255
                        if (Red < 0) Red = 0; //如果小于0则只能等于0
                        if (Green > 255) Green = 255;
                        if (Green < 0) Green = 0;
                        if (Blue > 255) Blue = 255;
                        if (Blue < 0) Blue = 0;
                        bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                    }
                    pictureBox_show.Refresh();//另外建立了一个图片框用于显示处理后的图像
                    pictureBox_show.Image = bt2;
                }
            }
        }



        //图像二值化？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnBinaryadjust_Click(object sender, EventArgs e)/*二值化处理方法该方法需要确定一个
阈值，大于阈值的用白色显示小于阈值的用黑色显示*/
        {
            if (!judge_pb_img_exit()) return;

            //如果滑块为0，利用类判别分析方法根据待处理图像的特点自动计算一个适当的阈值进行判断和二值化。
            if (trackBar_binary.Value == 0)
            {
                btn_binary_Click_by_default(sender, e);
            }
            else//否则根据滑块的值进行二值化
            {
                btn_binary_Click_by_trackBar_brightness_value(sender, e);
            }
        }
        private void trackBar_binary_Scroll(object sender, EventArgs e)
        {
            //拉动 二值化 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为二值化的调节值
            textBox_showBinary.Text = trackBar_binary.Value.ToString();
        }
        private void btnBinaryadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnBinaryadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnBinaryadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnBinaryadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }
        //滑块为0，利用类判别分析方法根据待处理图像的特点自动计算一个适当的阈值进行判断和二值化。
        public void btn_binary_Click_by_default(object sender, EventArgs e)
        {
            //用于存储该像素的灰度值
            int[,] array = new int[1000, 1000];
            int[] hd = new int[350];
            //用于存储某灰度值在整个图像中占的百分比
            double[] p = new double[350];
            //用于存储灰度类均值
            double[] uu = new double[350];
            //用于存储某灰度值的个数
            double[] tt = new double[350];
            //用于存储直方图之和
            double[] w = new double[350];
            //函数值
            double[] b = new double[350];
            //函数值最大值
            double max;
            double u = 0;
            //使得函数值最大的那个变量
            double maxb = 0;
            int r;
            Color cc1 = Color.FromArgb(255, 255, 255);
            Color cc2 = Color.FromArgb(0, 0, 0);
            Color c = new Color();
            //Bitmap box1 = new Bitmap(pictureBox_show.Image);
            Bitmap box1 = new Bitmap(original_image.Image);
            //获取每个像素的灰度值
            for (int i = 1; i < pictureBox_show.Image.Width - 1; i++)
            {
                for (int j = 1; j < pictureBox_show.Image.Height - 1; j++)
                {
                    c = box1.GetPixel(i, j);
                    r = c.R;
                    array[i, j] = r;
                }
            }
            //灰度值在0-255之间变换，再次扫描图像，把相同灰度值的累加起来
            for (int i = 1; i < pictureBox_show.Image.Width; i++)
            {
                for (int j = 1; j < pictureBox_show.Image.Height; j++)
                {
                    for (int k = 0; k < 255; k++)
                    {
                        if (array[i, j] == k)
                        {
                            tt[k] = tt[k] + 1;
                        }
                    }
                }
            }
            //求出图像里含有的各个灰度值所占的百分比
            for (int m = 0; m < 255; m++)
            {
                p[m] = tt[m] / (pictureBox_show.Image.Width * pictureBox_show.Image.Height);
            }
            //求灰度均值
            for (int n = 1; n < 256; n++)
            {
                u = u + (n - 1) * p[n];
            }
            //求灰度类均值和直方图和
            for (int i = 1; i < 256; i++)
            {
                uu[i] = uu[i - 1] + (i - 1) * p[i];
                w[i] = w[i - 1] + p[i];
                if (w[i] * (1 - w[i - 1]) != 0)
                {
                    b[i] = ((u * w[i] - uu[i]) * (u * w[i] - uu[i])) / (w[i] * (1 - w[i]));
                }
            }
            //初始化函数最大值
            max = b[0];
            //求出使函数达到最大值的变量
            for (int i = 0; i < 255; i++)
            {
                if (b[i] >= max)
                {
                    max = b[i];
                }
            }
            for (int j = 0; j < 255; j++)
            {
                if (b[j] == max)
                    maxb = j;
            }
            //最佳阈值就是maxb-1，然后根据阈值对灰度图像进行二值化处理
            for (int i = 1; i < pictureBox_show.Image.Width; i++)
            {
                for (int j = 1; j < pictureBox_show.Image.Height; j++)
                {
                    c = box1.GetPixel(i, j);
                    r = c.R;
                    if (r > (maxb - 1))
                        box1.SetPixel(i, j, cc2);
                    else
                        box1.SetPixel(i, j, cc1);
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = box1;
            }
        }
        //根据滑块的值进行二值化处理
        public void btn_binary_Click_by_trackBar_brightness_value(object sender, EventArgs e)
        {
            Color colorOrigin = new Color();//定义一个色彩变量对象
            double Red, Green, Blue, Y;//定义红绿蓝三色和亮度
            Bitmap Bmp1 = new Bitmap(original_image.Image);//定义一个位图文件并将图片框内的图像赋值给它
            int brightThreshole = new int();//定义整型的二值化阈值
            brightThreshole = trackBar_binary.Value;//根据滑动条的大小 给该阈值赋值，也可以直接赋值
            for (int i = 0; i < pictureBox_show.Image.Width; i++)
            {
                for (int j = 0; j < pictureBox_show.Image.Height; j++)//循环处理图像中的每一个像素点
                {
                    colorOrigin = Bmp1.GetPixel(i, j);//获取当前像素点的色彩信息
                    Red = colorOrigin.R; Green = colorOrigin.G; Blue = colorOrigin.B;//获取当前像素点的红绿蓝分量
                    Y = 0.59 * Red + 0.3 * Green + 0.11 * Blue;//计算当前像素点的亮度
                    if (Y > brightThreshole)//如果当前像素点的亮度大于指定阈值
                    {
                        Color ColorProcessed = Color.FromArgb(255, 255, 255); /*那么定义一个纯白
                        的色彩变量，即各分量均为255*/
                        Bmp1.SetPixel(i, j, ColorProcessed); //将白色变量赋给当前像素点
                    }
                    if (Y <= brightThreshole) //如果当前像素点的亮度小于指定阈值
                    {
                        Color ColorProcessed = Color.FromArgb(0, 0, 0); /*//那么定义一个纯黑的色彩
                        变量，即各分量均为0*/
                        Bmp1.SetPixel(i, j, ColorProcessed); //将黑色变量赋给当前像素点
                    }
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = Bmp1; //将重新生成的图片赋值给图片框
            }
        }


        //颜色通道选取确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_colorCollect_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            int pos;
            if (comboBox_colorCollect.Text.ToString().Equals("红"))
            {
                pos = 0;
            }
            else if (comboBox_colorCollect.Text.ToString().Equals("绿"))
            {
                pos = 1;
            }
            else//蓝
            {
                pos = 2;
            }

            Color ColorOrigin = new Color();//定义一个色彩变量对象
            double Red, Green, Blue, Y; //定义红、绿、蓝三色和亮度
            Bitmap Bmp1 = new Bitmap(original_image.Image); //定义一个位图文件并将图片框内的图像赋值给它
            for (int i = 0; i <= pictureBox_show.Image.Width - 1; i++)
            {
                for (int j = 0; j <= pictureBox_show.Image.Height - 1; j++)//循环处理图像中的每一个像素点
                {
                    int[] arr = new int[3];
                    ColorOrigin = Bmp1.GetPixel(i, j); //获取当前像素点的色彩信息
                    arr[0] = (int)ColorOrigin.R;//获取当前像素点的红色分量
                    arr[1] = (int)ColorOrigin.G;//获取当前像素点的绿色分量
                    arr[2] = (int)ColorOrigin.B;//获取当前像素点的蓝色分量

                    //Red = ColorOrigin.R; //获取当前像素点的红色分量
                    //Green = ColorOrigin.G; //获取当前像素点的绿色分量
                    //Blue = ColorOrigin.B; //获取当前像素点的蓝色分量
                    Color ColorProcessed = Color.FromArgb(arr[pos], arr[pos], arr[pos]); //用红色分量作为图像的灰度，也可用绿色或蓝色。
                    Bmp1.SetPixel(i, j, ColorProcessed); //将新的灰度值赋给当前像素点
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = Bmp1; //将重新生成的图片赋值给图片框
            }
            //MessageBox.Show(comboBox_colorCollect.Text.ToString());
        }
        private void btnColoradjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnColoradjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnColoradjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnColoradjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }


        //图像平滑确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnSmoothadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            string value = comboBox_smoothCollect.Text.ToString();
            if (value.Equals("四邻域平均"))
            {
                image_smooth_四邻域平均(sender, e);
            }
            else if (value.Equals("八邻域平均"))
            {
                image_smooth_八邻域平均(sender, e);
            }
            else if (value.Equals("最大值滤波"))
            {
                image_smooth_最大值滤波(sender, e);
            }
            else if (value.Equals("最小值滤波"))
            {
                image_smooth_最小值滤波(sender, e);
            }
            else if (value.Equals("中值滤波"))
            {
                image_smooth_中值滤波(sender, e);

            }
            else if (value.Equals("自适应中值滤波"))
            {
                image_smooth_自适应中值滤波(sender, e);
            }
            else if (value.Equals("高斯滤波"))//修正平均滤波
            {

                // 使用标准差为 1.5、5x5 的滤波器大小
                Bitmap bt1 = new Bitmap(pictureBox_show.Image);
                double standardDeviation;
                Bitmap filteredImage;
                if (!string.IsNullOrWhiteSpace(textBox_gaussianVariance.Text))
                {
                    standardDeviation = double.Parse(textBox_gaussianVariance.Text);
                    filteredImage = Apply(bt1, standardDeviation, 5);
                }
                else
                {
                    filteredImage = Apply(bt1, 1.5, 5);

                }

                //Bitmap filteredImage =Apply(bt1, 1.5, 5);
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = filteredImage; //将重新生成的图片赋值给图片框
            }

        }
        private void image_smooth_四邻域平均(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image); //定义两个位图对象
            int R1, R2, R3, R4, Red;
            int G1, G2, G3, G4, Green;
            int B1, B2, B3, B4, Blue;
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    R1 = bt1.GetPixel(i, j - 1).R;
                    R2 = bt1.GetPixel(i, j + 1).R;
                    R3 = bt1.GetPixel(i - 1, j).R;
                    R4 = bt1.GetPixel(i + 1, j).R;
                    Red = (R1 + R2 + R3 + R4) / 5;
                    G1 = bt1.GetPixel(i, j - 1).G;
                    G2 = bt1.GetPixel(i, j + 1).G;
                    G3 = bt1.GetPixel(i - 1, j).G;
                    G4 = bt1.GetPixel(i + 1, j).G;
                    Green = (G1 + G2 + G3 + G4) / 5;
                    B1 = bt1.GetPixel(i, j - 1).B;
                    B2 = bt1.GetPixel(i, j + 1).B;
                    B3 = bt1.GetPixel(i - 1, j).B;
                    B4 = bt1.GetPixel(i + 1, j).B;
                    Blue = (B1 + B2 + B3 + B4) / 5;
                    bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }
        }
        private void image_smooth_八邻域平均(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image); //定义两个位图对象
            int R1, R2, R3, R4, R5, R6, R7, R8, Red;
            int G1, G2, G3, G4, G5, G6, G7, G8, Green;
            int B1, B2, B3, B4, B5, B6, B7, B8, Blue;
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    R1 = bt1.GetPixel(i - 1, j - 1).R;
                    R2 = bt1.GetPixel(i, j - 1).R;
                    R3 = bt1.GetPixel(i + 1, j - 1).R;
                    R4 = bt1.GetPixel(i - 1, j).R;
                    R5 = bt1.GetPixel(i + 1, j).R;
                    R6 = bt1.GetPixel(i - 1, j + 1).R;
                    R7 = bt1.GetPixel(i, j + 1).R;
                    R8 = bt1.GetPixel(i + 1, j + 1).R;
                    Red = (int)(R1 + R2 + R3 + R4 + R5 + R6 + R7 + R8) / 8;
                    G1 = bt1.GetPixel(i - 1, j - 1).G;
                    G2 = bt1.GetPixel(i, j - 1).G;
                    G3 = bt1.GetPixel(i + 1, j - 1).G;
                    G4 = bt1.GetPixel(i - 1, j).G;
                    G5 = bt1.GetPixel(i + 1, j).G;
                    G6 = bt1.GetPixel(i - 1, j + 1).G;
                    G7 = bt1.GetPixel(i, j + 1).G;
                    G8 = bt1.GetPixel(i + 1, j + 1).G;
                    Green = (int)(G1 + G2 + G3 + G4 + G5 + G6 + G7 + G8) / 8;
                    B1 = bt1.GetPixel(i - 1, j - 1).B;
                    B2 = bt1.GetPixel(i, j - 1).B;
                    B3 = bt1.GetPixel(i + 1, j - 1).B;
                    B4 = bt1.GetPixel(i - 1, j).B;
                    B5 = bt1.GetPixel(i + 1, j).B;
                    B6 = bt1.GetPixel(i - 1, j + 1).B;
                    B7 = bt1.GetPixel(i, j + 1).B;
                    B8 = bt1.GetPixel(i + 1, j + 1).B;
                    Blue = (int)(B1 + B2 + B3 + B4 + B5 + B6 + B7 + B8) / 8;
                    bt2.SetPixel(i, j, Color.FromArgb(Red, Green, Blue));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }
        }
        private void image_smooth_最大值滤波(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            int rr, r1;
            //扫描图像的每个像素
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    rr = 0; //设定一个0初值，取邻域中的每个值与它比较，哪个更大就赋值给它
                            //为了处理3×3的像素块设置一个循环，实际就是实现8邻域的最大值滤波
                    for (int m = -1; m < 2; m++)
                    {
                        for (int n = -1; n < 2; n++)
                        {
                            //获取该坐标的像素
                            c = bt1.GetPixel(i + m, j + n);
                            r1 = c.R;
                            if (r1 > rr)
                                rr = r1;
                        }
                    }
                    bt2.SetPixel(i, j, Color.FromArgb(rr, rr, rr));
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = bt2;
            }


        }
        private void image_smooth_最小值滤波(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            int rr, r1;
            //扫描图像的每个像素
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    rr = 255; //设定一个255初值，取邻域中的每个值与它比较，哪个更小就赋值给它
                              //为了处理3×3的像素块设置一个循环，实际就是实现8邻域的最小值滤波
                    for (int m = -1; m < 2; m++)
                    {
                        for (int n = -1; n < 2; n++)
                        {
                            //获取该坐标的像素
                            c = bt1.GetPixel(i + m, j + n);
                            r1 = c.R;
                            rr = r1;
                            if (r1 > rr)
                                rr = r1;
                        }
                    }
                    bt2.SetPixel(i, j, Color.FromArgb(rr, rr, rr));
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = bt2;
            }
        }
        private void image_smooth_中值滤波(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            int rr, r1, dm, m;
            //设置一个数组用于储存3×3像素快的r分量值
            int[] dt = new int[20];
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    rr = 0; m = 0;
                    for (int k = -1; k < 2; k++)
                    {
                        for (int n = -1; n < 2; n++)
                        {
                            //获取该坐标的像素并存入数组dt[]中
                            c = bt1.GetPixel(i + k, j + n);
                            r1 = c.R;
                            dt[m++] = r1;
                        }
                    }
                    for (int p = 0; p < m - 1; p++)
                    {
                        for (int q = p + 1; q < m; q++)
                        {
                            //对存与数组里的数据进行从大到小的排序
                            if (dt[p] > dt[q])
                            {
                                dm = dt[p];
                                dt[p] = dt[q];
                                dt[q] = dm;
                            }
                        }
                    }
                    //获取数值所有存储数据的中间值
                    rr = dt[(int)(m / 2)];
                    bt2.SetPixel(i, j, Color.FromArgb(rr, rr, rr));
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = bt2;
            }

        }


        //-————————————————————————————————————————————
        private void image_smooth_自适应中值滤波(object sender, EventArgs e)
        {
            Bitmap image = new Bitmap(pictureBox_show.Image);

            int maxWindowSize = 7; // 最大窗口大小
            Bitmap filteredImage = selfAdaptMedianFilter(image, maxWindowSize);
            pictureBox_show.Refresh();
            pictureBox_show.Image = filteredImage;
        }
        //返回自适应中值滤波之后的图像？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        public static Bitmap selfAdaptMedianFilter(Bitmap image, int maxWindowSize)
        {
            Bitmap result = new Bitmap(image.Width, image.Height);

            int width = image.Width;
            int height = image.Height;

            int halfMaxWindowSize = maxWindowSize / 2;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    int windowSize = 3; // 初始滤波器窗口大小为3x3

                    while (windowSize <= maxWindowSize)
                    {
                        int halfWindowSize = windowSize / 2;
                        int[] pixels = new int[windowSize * windowSize];

                        int index = 0;
                        for (int dy = -halfWindowSize; dy <= halfWindowSize; dy++)
                        {
                            for (int dx = -halfWindowSize; dx <= halfWindowSize; dx++)
                            {
                                int nx = x + dx;
                                int ny = y + dy;

                                // 边界处理，超出图像范围的像素使用原始像素值
                                if (nx < 0 || nx >= width || ny < 0 || ny >= height)
                                {
                                    pixels[index] = image.GetPixel(x, y).ToArgb();
                                }
                                else
                                {
                                    pixels[index] = image.GetPixel(nx, ny).ToArgb();
                                }

                                index++;
                            }
                        }

                        Array.Sort(pixels);

                        int median = pixels[pixels.Length / 2];
                        int currentPixel = image.GetPixel(x, y).ToArgb();

                        if (currentPixel > pixels[0] && currentPixel < pixels[pixels.Length - 1])
                        {
                            // 当前像素不受噪声干扰，保持原始像素值
                            result.SetPixel(x, y, Color.FromArgb(currentPixel));
                            break;
                        }
                        else
                        {
                            // 增加滤波器窗口的大小
                            windowSize += 2;

                            // 达到最大滤波器窗口的大小仍然没有找到合适的像素值，使用中值
                            if (windowSize > maxWindowSize)
                            {
                                result.SetPixel(x, y, Color.FromArgb(median));
                            }
                        }
                    }
                }
            }

            return result;
        }
        private static int[] GetWindowValues(Bitmap image, int x, int y, int windowSize)
        {
            int halfWindowSize = windowSize / 2;
            int[] values = new int[windowSize * windowSize];
            int index = 0;

            for (int j = -halfWindowSize; j <= halfWindowSize; j++)
            {
                for (int i = -halfWindowSize; i <= halfWindowSize; i++)
                {
                    int neighborX = x + i;
                    int neighborY = y + j;

                    if (neighborX < 0 || neighborX >= image.Width || neighborY < 0 || neighborY >= image.Height)
                    {
                        values[index] = 0; // or any default value for out-of-bounds pixels
                    }
                    else
                    {
                        values[index] = image.GetPixel(neighborX, neighborY).R;
                    }

                    index++;
                }
            }

            return values;
        }


        private void image_smooth_修正平均滤波(object sender, EventArgs e)
        {
            Color c = new Color();
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            int rr, r1, dm, m;
            //设置一个数组用于储存3×3像素快的r分量值
            int[] dt = new int[20];
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    rr = 0; m = 0;
                    for (int k = -1; k < 2; k++)
                    {
                        for (int n = -1; n < 2; n++)
                        {
                            //获取该坐标的像素
                            c = bt1.GetPixel(i + k, j + n);
                            r1 = c.R;
                            dt[m] = r1;
                            m++;
                        }
                    }
                    for (int p = 0; p < m - 1; p++)
                    {
                        for (int q = p + 1; q < m; q++)
                        {
                            //对存与数组里的数据进行从大到小的排序
                            if (dt[p] > dt[q])
                            {
                                dm = dt[p];
                                dt[p] = dt[q];
                                dt[q] = dm;
                            }
                        }
                    }
                    //获取去掉最大、最小值后的所有数的平均值，即修正后的平均值
                    for (int l = 1; l < m - 1; l++)
                        rr += dt[l];
                    rr = (int)(rr / (m - 2));
                    bt2.SetPixel(i, j, Color.FromArgb(rr, rr, rr));
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = bt2;
            }
        }

        //返回高斯滤波之后的图像？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        public static Bitmap Apply(Bitmap image, double sigma, int kernelSize)
        {
            Bitmap result = new Bitmap(image.Width, image.Height);

            int radius = kernelSize / 2;
            double[,] kernel = GenerateGaussianKernel(sigma, kernelSize);

            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    double redSum = 0;
                    double greenSum = 0;
                    double blueSum = 0;
                    double weightSum = 0;

                    for (int j = -radius; j <= radius; j++)
                    {
                        for (int i = -radius; i <= radius; i++)
                        {
                            int posX = x + i;
                            int posY = y + j;

                            if (posX >= 0 && posX < image.Width && posY >= 0 && posY < image.Height)
                            {
                                Color pixel = image.GetPixel(posX, posY);
                                double weight = kernel[i + radius, j + radius];

                                redSum += pixel.R * weight;
                                greenSum += pixel.G * weight;
                                blueSum += pixel.B * weight;
                                weightSum += weight;
                            }
                        }
                    }

                    int red = (int)Math.Round(redSum / weightSum);
                    int green = (int)Math.Round(greenSum / weightSum);
                    int blue = (int)Math.Round(blueSum / weightSum);

                    red = Math.Max(0, Math.Min(255, red));
                    green = Math.Max(0, Math.Min(255, green));
                    blue = Math.Max(0, Math.Min(255, blue));

                    Color filteredColor = Color.FromArgb(red, green, blue);
                    result.SetPixel(x, y, filteredColor);
                }
            }

            return result;
        }
        private static double[,] GenerateGaussianKernel(double sigma, int size)
        {
            double[,] kernel = new double[size, size];
            double sum = 0;

            int radius = size / 2;

            for (int y = -radius; y <= radius; y++)
            {
                for (int x = -radius; x <= radius; x++)
                {
                    double exponent = -(x * x + y * y) / (2 * sigma * sigma);
                    double weight = Math.Exp(exponent) / (2 * Math.PI * sigma * sigma);
                    kernel[x + radius, y + radius] = weight;
                    sum += weight;
                }
            }

            // 标准化核函数
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    kernel[x, y] /= sum;
                }
            }
            return kernel;
        }
        private void btnSmoothadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnSmoothadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnSmoothadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnSmoothadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }


        //叠加原图的按钮
        private void btn_edgeFillOrigin_Click(object sender, EventArgs e)
        {
            Bitmap originalImage = new Bitmap(original_image.Image);// 原始彩色图像
            Bitmap edgeImage = new Bitmap(pictureBox_show.Image);// 应用***算子，得到边缘化图像
            Bitmap overlaidImage = new Bitmap(pictureBox_show.Image);//将边缘化图像叠加到原图上

            for (int i = 0; i < originalImage.Width; i++)
            {
                for (int j = 0; j < originalImage.Height; j++)
                {
                    Color originalColor = originalImage.GetPixel(i, j);
                    Color edgeColor = edgeImage.GetPixel(i, j);

                    int finalR = Math.Min(255, originalColor.R + edgeColor.R);
                    int finalG = Math.Min(255, originalColor.G + edgeColor.G);
                    int finalB = Math.Min(255, originalColor.B + edgeColor.B);

                    Color overlaidColor = Color.FromArgb(finalR, finalG, finalB);
                    overlaidImage.SetPixel(i, j, overlaidColor);
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = overlaidImage;
            }

        }

        ////图像锐化确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnSharpeningadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            string value = comboBox_sharpeningCollect.Text.ToString();
            if (value.Equals("水平垂直差分法"))
            {
                image_sharpening_水平垂直差分法(sender, e);

            }
            else if (value.Equals("soble算子"))
            {
                image_sharpening_soble算子(sender, e);
                //sobel_Click(sender, e);
            }
            else if (value.Equals("robert算子"))
            {
                image_sharpening_robert算子(sender, e);
            }
            else if (value.Equals("prewitt算子"))
            {
                image_sharpening_prewitt算子(sender, e);
            }
            else if (value.Equals("Laplacian算子"))
            {
                image_sharpening_拉普拉斯算子(sender, e);
            }
            else if (value.Equals("robinson算子"))
            {
                image_sharpening_robinson算子(sender, e);
            }
            else if (value.Equals("kirsch算子"))
            {
                image_sharpening_kirsch算子(sender, e);
            }
        }
        private void image_sharpening_水平垂直差分法(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(original_image.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);


            int R1, R2, R3, R4;
            int G1, G2, G3, G4;
            int B1, B2, B3, B4;
            for (int i = 0; i < bt1.Width - 1; i++)
            {
                for (int j = 0; j < bt1.Height - 1; j++)
                {
                    //取两个分量差的和值
                    R1 = bt1.GetPixel(i, j).R;//中心
                    R2 = bt1.GetPixel(i + 1, j).R;//取右边
                    R3 = bt1.GetPixel(i, j + 1).R;//取下边
                    R4 = Math.Abs(R1 - R2) + Math.Abs(R1 - R3);
                    G1 = bt1.GetPixel(i, j).G;
                    G2 = bt1.GetPixel(i + 1, j).G;
                    G3 = bt1.GetPixel(i, j + 1).G;
                    G4 = Math.Abs(G1 - G2) + Math.Abs(G1 - G3);
                    B1 = bt1.GetPixel(i, j).B;
                    B2 = bt1.GetPixel(i + 1, j).B;
                    B3 = bt1.GetPixel(i, j + 1).B;
                    B4 = Math.Abs(B1 - B2) + Math.Abs(B1 - B3);
                    if (R4 >= 255) R4 = 255;
                    if (G4 >= 255) G4 = 255;//判断是否超出各分量允许的范围，如果大于255则只能等于255
                    if (B4 >= 255) B4 = 255;
                    bt2.SetPixel(i, j, Color.FromArgb(R4, G4, B4));
                }
                pictureBox_show.Refresh();
                pictureBox_show.Image = bt2;
            }

        }
        private void image_sharpening_soble算子(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap sharpened = new Bitmap(pictureBox_show.Image);

            // 创建Sobel算子滤波器
            //  int[,] sobelX = new int[,]
            //{
            //    { -1, 0, 1 },
            //    { -2, 0, 2 },
            //    { -1, 0, 1 }
            //};
            //  int[,] sobelY = new int[,]
            //  {
            //    { -1, -2, -1 },
            //    { 0, 0, 0 },
            //    { 1, 2, 1 }
            //  };

            int[,] sobelX = new int[,]
            {
            { -3, 0, 3 },
            { -10, 0, 10 },
            { -3, 0, 3 }
            };

            int[,] sobelY = new int[,]
            {
            { -3, -10, -3 },
            { 0, 0, 0 },
            { 3, 10, 3 }
            };

            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    int sumXr = 0, sumXg = 0, sumXb = 0;
                    int sumYr = 0, sumYg = 0, sumYb = 0;

                    for (int k = -1; k <= 1; k++)
                    {
                        for (int l = -1; l <= 1; l++)
                        {
                            Color pixelColor = bt1.GetPixel(i + k, j + l);
                            int sobelXValue = sobelX[k + 1, l + 1];
                            int sobelYValue = sobelY[k + 1, l + 1];

                            sumXr += pixelColor.R * sobelXValue;
                            sumXg += pixelColor.G * sobelXValue;
                            sumXb += pixelColor.B * sobelXValue;

                            sumYr += pixelColor.R * sobelYValue;
                            sumYg += pixelColor.G * sobelYValue;
                            sumYb += pixelColor.B * sobelYValue;
                        }
                    }
                    //double gradientR = Math.Sqrt(sumXr * sumXr + sumYr * sumYr);
                    //double gradientG = Math.Sqrt(sumXg * sumXg + sumYg * sumYg);
                    //double gradientB = Math.Sqrt(sumXb * sumXb + sumYb * sumYb);

                    int gradientR = Math.Max(0, Math.Min(255, Math.Abs(sumXr) + Math.Abs(sumYr)));
                    int gradientG = Math.Max(0, Math.Min(255, Math.Abs(sumXg) + Math.Abs(sumYg)));
                    int gradientB = Math.Max(0, Math.Min(255, Math.Abs(sumXb) + Math.Abs(sumYb)));

                    Color edgeColor = Color.FromArgb(gradientR, gradientG, gradientB);
                    sharpened.SetPixel(i, j, edgeColor);
                    //pictureBox_show.Refresh();
                }
            }
            pictureBox_show.Image = sharpened;
        }

        private void image_sharpening_robert算子(object sender, EventArgs e)
        {
            Bitmap originalBt = new Bitmap(pictureBox_show.Image);
            Bitmap edgeBt = new Bitmap(originalBt.Width, originalBt.Height);

            int[,] robertsX = { { -1, 0 }, { 0, 1 } }; // Roberts算子水平方向模板
            int[,] robertsY = { { 0, -1 }, { 1, 0 } }; // Roberts算子垂直方向模板

            int diffXr, diffXg, diffXb;
            int diffYr, diffYg, diffYb;
            for (int i = 0; i < originalBt.Width - 1; i++)
            {
                for (int j = 0; j < originalBt.Height - 1; j++)
                {
                    Color pixel5 = originalBt.GetPixel(i, j);
                    Color pixel6 = originalBt.GetPixel(i, j + 1);
                    Color pixel8 = originalBt.GetPixel(i + 1, j);
                    Color pixel9 = originalBt.GetPixel(i + 1, j + 1);

                    diffXr = pixel9.R - pixel5.R;
                    diffXg = pixel9.G - pixel5.G;
                    diffXb = pixel9.B - pixel5.B;

                    diffYr = pixel8.R - pixel6.R;
                    diffYg = pixel8.G - pixel6.G;
                    diffYb = pixel8.B - pixel6.B;


                    int gradientR = Math.Max(0, Math.Min(255, Math.Abs(diffXr) + Math.Abs(diffYr)));
                    int gradientG = Math.Max(0, Math.Min(255, Math.Abs(diffXr) + Math.Abs(diffYg)));
                    int gradientB = Math.Max(0, Math.Min(255, Math.Abs(diffXr) + Math.Abs(diffYb)));

                    edgeBt.SetPixel(i, j, Color.FromArgb(gradientR, gradientG, gradientB));
                }
            }
            pictureBox_show.Refresh(); // 刷新图片框
            pictureBox_show.Image = edgeBt;
        }
        private void image_sharpening_prewitt算子(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap sharpened = new Bitmap(pictureBox_show.Image);

            //prewitt算子滤波器模板
            int[,] prewittY = new int[,]
            {
        { -1, 0, 1 },
        { -1, 0, 1 },
        { -1, 0, 1 }
            };

            int[,] prewittX = new int[,]
            {
        { -1, -1, -1 },
        { 0, 0, 0 },
        { 1, 1, 1 }
            };

            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    int sumXr = 0, sumXg = 0, sumXb = 0;
                    int sumYr = 0, sumYg = 0, sumYb = 0;

                    for (int k = -1; k <= 1; k++)
                    {
                        for (int l = -1; l <= 1; l++)
                        {
                            Color pixelColor = bt1.GetPixel(i + k, j + l);
                            int prewittXValue = prewittX[k + 1, l + 1];
                            int prewittYValue = prewittY[k + 1, l + 1];

                            sumXr += pixelColor.R * prewittXValue;
                            sumXg += pixelColor.G * prewittXValue;
                            sumXb += pixelColor.B * prewittXValue;

                            sumYr += pixelColor.R * prewittYValue;
                            sumYg += pixelColor.G * prewittYValue;
                            sumYb += pixelColor.B * prewittYValue;
                        }
                    }

                    int gradientR = Math.Max(0, Math.Min(255, Math.Abs(sumXr) + Math.Abs(sumYr)));
                    int gradientG = Math.Max(0, Math.Min(255, Math.Abs(sumXg) + Math.Abs(sumYg)));
                    int gradientB = Math.Max(0, Math.Min(255, Math.Abs(sumXb) + Math.Abs(sumYb)));

                    Color edgeColor = Color.FromArgb(gradientR, gradientG, gradientB);
                    sharpened.SetPixel(i, j, edgeColor);
                }
            }
            pictureBox_show.Image = sharpened;

        }
        private void image_sharpening_拉普拉斯算子(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(original_image.Image);
            Bitmap sharpened = new Bitmap(pictureBox_show.Image);

            // 创建Laplacian算子滤波器
            int[,] Laplacian = new int[,]
            {
              { 1, 1, 1 },
              { 1, -8, 1 },
              { 1, 1, 1 }
            };

            //  int[,] Laplacian = new int[,]
            //{
            //    { 0, 1, 0 },
            //    { 1, -4, 1 },
            //    { 0, 1, 0 }
            //};

            //  int[,] Laplacian = new int[,]
            //{
            //    { 0, 2, 0 },
            //    { 2, -8, 2 },
            //    { 0, 2, 0 }
            //};

            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    int sumr = 0, sumg = 0, sumb = 0;
                    Color pixelColor;
                    for (int k = -1; k <= 1; k++)
                    {
                        for (int l = -1; l <= 1; l++)
                        {
                            pixelColor = bt1.GetPixel(i + k, j + l);
                            int LaplacianValue = Laplacian[k + 1, l + 1];

                            sumr += pixelColor.R * LaplacianValue;
                            sumg += pixelColor.G * LaplacianValue;
                            sumb += pixelColor.B * LaplacianValue;
                        }
                    }
                    int resultR = Math.Max(0, Math.Min(255, sumr));
                    int resultG = Math.Max(0, Math.Min(255, sumg));
                    int resultB = Math.Max(0, Math.Min(255, sumb));

                    Color edgeColor = Color.FromArgb(resultR, resultG, resultB);
                    sharpened.SetPixel(i, j, edgeColor);
                    //pictureBox_show.Refresh();
                }
            }
            pictureBox_show.Image = sharpened;
        }
        private void image_sharpening_robinson算子(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap edgeImage = new Bitmap(bt1.Width, bt1.Height);

            int[,,] robinsonTemplates = {
    {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}},
    {{0, 1, 2}, {-1, 0, 1}, {-2, -1, 0}},
    {{1, 2, 1}, {0, 0, 0}, {-1, -2, -1}},
    {{2, 1, 0}, {1, 0, -1}, {0, -1, -2}},
    {{1, 0, -1}, {2, 0, -2}, {1, 0, -1}},
    {{0, -1, -2}, {1, 0, -1}, {2, 1, 0}},
    {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}},
    {{-2, -1, 0}, {-1, 0, 1}, {0, 1, 2}}
};
            // 对每个像素应用Kirsch算子
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    int maxGradientR = 0;
                    int maxGradientG = 0;
                    int maxGradientB = 0;

                    // 对每个模板进行卷积计算
                    for (int t = 0; t < 8; t++)
                    {
                        int gradientR = 0;
                        int gradientG = 0;
                        int gradientB = 0;

                        // 计算模板与图像区域的卷积
                        for (int m = -1; m <= 1; m++)
                        {
                            for (int n = -1; n <= 1; n++)
                            {
                                gradientR += robinsonTemplates[t, m + 1, n + 1] * bt1.GetPixel(i + m, j + n).R;
                                gradientG += robinsonTemplates[t, m + 1, n + 1] * bt1.GetPixel(i + m, j + n).G;
                                gradientB += robinsonTemplates[t, m + 1, n + 1] * bt1.GetPixel(i + m, j + n).B;
                            }
                        }

                        int SumR = Math.Max(0, Math.Min(255, gradientR));
                        int SumG = Math.Max(0, Math.Min(255, gradientG));
                        int SumB = Math.Max(0, Math.Min(255, gradientB));
                        SumR /= 4; SumG /= 4; SumB /= 4;

                        Color edgeColor = Color.FromArgb(SumR, SumG, SumB);
                        edgeImage.SetPixel(i, j, edgeColor);
                    }
                }
            }
            pictureBox_show.Refresh(); // 刷新图片框
            pictureBox_show.Image = edgeImage;

        }
        private void image_sharpening_kirsch算子(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap edgeImage = new Bitmap(bt1.Width, bt1.Height);

            int[,,] krischTemplates = {
      {{-3, -3, 5}, {-3, 0, 5}, {-3, -3, 5}},
    {{-3, 5, 5}, {-3, 0, 5}, {-3, -3, -3}},
    {{5, 5, 5}, {-3, 0, -3}, {-3, -3, -3}},
    {{5, 5, -3}, {5, 0, -3}, {-3, -3, -3}},
    {{5, -3, -3}, {5, 0, -3}, {5, -3, -3}},
    {{-3, -3, -3}, {5, 0, -3}, {5, 5, -3}},
    {{-3, -3, -3}, {-3, 0, -3}, {5, 5, 5}},
    {{-3, -3, -3}, {-3, 0, 5}, {-3, 5, 5}}};
            // 对每个像素应用Kirsch算子
            for (int i = 1; i < bt1.Width - 1; i++)
            {
                for (int j = 1; j < bt1.Height - 1; j++)
                {
                    int maxGradientR = 0;
                    int maxGradientG = 0;
                    int maxGradientB = 0;

                    // 对每个模板进行卷积计算
                    for (int t = 0; t < 8; t++)
                    {
                        int gradientR = 0;
                        int gradientG = 0;
                        int gradientB = 0;

                        // 计算模板与图像区域的卷积
                        for (int m = -1; m <= 1; m++)
                        {
                            for (int n = -1; n <= 1; n++)
                            {
                                gradientR += krischTemplates[t, m + 1, n + 1] * bt1.GetPixel(i + m, j + n).R;
                                gradientG += krischTemplates[t, m + 1, n + 1] * bt1.GetPixel(i + m, j + n).G;
                                gradientB += krischTemplates[t, m + 1, n + 1] * bt1.GetPixel(i + m, j + n).B;
                            }
                        }

                        int SumR = Math.Max(0, Math.Min(255, gradientR));
                        int SumG = Math.Max(0, Math.Min(255, gradientG));
                        int SumB = Math.Max(0, Math.Min(255, gradientB));
                        SumR /= 4; SumG /= 4; SumB /= 4;

                        Color edgeColor = Color.FromArgb(SumR, SumG, SumB);
                        edgeImage.SetPixel(i, j, edgeColor);
                    }
                }
            }
            pictureBox_show.Refresh(); // 刷新图片框
            pictureBox_show.Image = edgeImage;
        }
        private void btnSharpeningadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnSharpeningadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnSharpeningadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnSharpeningadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }


        //彩色图像的膨胀函数
        private void ColorDilation()
        {
            int target;//SE大小
            int target_binary;
            if (int.TryParse(textBox_structureElementValue.Text, out target))
            {
                if (target % 2 != 0)//奇数
                {
                    // 转换成功，可以使用 target 变量和 target_binary 变量进行后续操作
                    target = int.Parse(textBox_structureElementValue.Text); // 均值
                    target_binary = target / 2;
                }
                else
                {
                    // 转换失败，弹窗提示报错
                    MessageBox.Show("请输入奇数值", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                // 转换失败，弹窗提示报错
                MessageBox.Show("输入的文本不是有效的数字", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            // 创建膨胀后的图像对象
            Bitmap dilatedImage = new Bitmap(bt1.Width, bt1.Height);

            // 定义结构元素大小和形状
            int structElementSize = target;  // 结构元素大小
            int structElementHalfSize = target_binary;

            // 循环遍历图像的每个像素
            for (int i = structElementHalfSize; i < bt1.Width - structElementHalfSize; i++)
            {
                for (int j = structElementHalfSize; j < bt1.Height - structElementHalfSize; j++)
                {
                    // 创建一个颜色数组来存储每个颜色通道的值
                    int[] redChannel = new int[structElementSize * structElementSize];
                    int[] greenChannel = new int[structElementSize * structElementSize];
                    int[] blueChannel = new int[structElementSize * structElementSize];

                    int index = 0;

                    // 循环遍历结构元素的每个像素
                    for (int k = -structElementHalfSize; k <= structElementHalfSize; k++)
                    {
                        for (int l = -structElementHalfSize; l <= structElementHalfSize; l++)
                        {
                            // 获取结构元素的颜色
                            Color structElementColor = bt1.GetPixel(i + k, j + l);

                            // 存储颜色通道的值
                            redChannel[index] = structElementColor.R;
                            greenChannel[index] = structElementColor.G;
                            blueChannel[index] = structElementColor.B;

                            index++;
                        }
                    }

                    // 对每个颜色通道进行排序并获取膨胀后的颜色值
                    Array.Sort(redChannel);
                    Array.Sort(greenChannel);
                    Array.Sort(blueChannel);

                    // 获取膨胀后的颜色值
                    int dilatedRed = redChannel[structElementSize * structElementSize - 1];
                    int dilatedGreen = greenChannel[structElementSize * structElementSize - 1];
                    int dilatedBlue = blueChannel[structElementSize * structElementSize - 1];

                    // 设置膨胀后的颜色值到膨胀图像中
                    dilatedImage.SetPixel(i, j, Color.FromArgb(dilatedRed, dilatedGreen, dilatedBlue));
                }
            }

            pictureBox_show.Image = dilatedImage;

        }


        //彩色图像腐蚀
        private void ColorErosion()
        {
            int target;//SE大小
            int target_binary;
            if (int.TryParse(textBox_structureElementValue.Text, out target))
            {
                if (target % 2 != 0)//奇数
                {
                    // 转换成功，可以使用 target 变量和 target_binary 变量进行后续操作
                    target = int.Parse(textBox_structureElementValue.Text); // 均值
                    target_binary = target / 2;
                }
                else
                {
                    // 转换失败，弹窗提示报错
                    MessageBox.Show("请输入奇数值", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                // 转换失败，弹窗提示报错
                MessageBox.Show("输入的文本不是有效的数字", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Bitmap bt1 = new Bitmap(pictureBox_show.Image);

            // 创建腐蚀后的图像对象
            Bitmap erodedImage = new Bitmap(bt1.Width, bt1.Height);

            // 定义结构元素大小和形状
            int structElementSize = target;  // 结构元素大小
            int structElementHalfSize = target_binary;


            for (int i = structElementHalfSize; i < bt1.Width - structElementHalfSize; i++)
            {
                for (int j = structElementHalfSize; j < bt1.Height - structElementHalfSize; j++)
                {
                    int minRed = 255;
                    int minGreen = 255;
                    int minBlue = 255;

                    for (int k = -structElementHalfSize; k <= structElementHalfSize; k++)
                    {
                        for (int l = -structElementHalfSize; l <= structElementHalfSize; l++)
                        {
                            Color pixelColor = bt1.GetPixel(i + k, j + l);
                            if (pixelColor.R < minRed)
                            {
                                minRed = pixelColor.R;
                            }
                            if (pixelColor.G < minGreen)
                            {
                                minGreen = pixelColor.G;
                            }
                            if (pixelColor.B < minBlue)
                            {
                                minBlue = pixelColor.B;
                            }
                        }
                    }

                    erodedImage.SetPixel(i, j, Color.FromArgb(minRed, minGreen, minBlue));
                }
            }
            pictureBox_show.Image = erodedImage;

        }

        //图像二值化变换的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnBinaryChangeadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            string value = comboBox_binaryChangeCollect.Text.ToString();

            string pic_category = comboBox_picCategory.Text.ToString();//图片类型


            if (pic_category.Equals("二值图"))//二值图
            {
                if (value.Equals("膨胀"))
                {
                    BinaryDilation();
                }
                else if (value.Equals("腐蚀"))
                {
                    BinaryErosion();
                }
                else if (value.Equals("开启"))
                {
                    BinaryErosion(); //先腐蚀
                    BinaryDilation(); //再膨胀
                }
                else if (value.Equals("闭合"))
                {
                    BinaryDilation(); //先膨胀
                    BinaryErosion(); //再腐蚀
                }
                else if (value.Equals("边缘提取"))
                {
                    binary_handle_change_边缘提取(sender, e);
                }
                else if (value.Equals("顶帽运算"))
                {
                    binary_top_hat(sender, e);

                }
                else if (value.Equals("黑帽运算"))
                {
                    binary_black_hat(sender, e);
                }
            }
            else//彩色图像和灰度图像
            {
                if (value.Equals("膨胀"))
                {
                    ColorDilation();
                }
                else if (value.Equals("腐蚀"))
                {
                    ColorErosion();
                }
                else if (value.Equals("开启"))
                {
                    ColorErosion(); //先腐蚀
                    ColorDilation(); //再膨胀
                }
                else if (value.Equals("闭合"))
                {
                    ColorDilation(); //先膨胀
                    ColorErosion(); //再腐蚀
                }
                else if (value.Equals("边缘提取"))
                {
                    color_handle_change_边缘提取(sender, e);
                }
                else if (value.Equals("顶帽运算"))
                {
                    color_top_hat(sender, e);
                }
                else if (value.Equals("黑帽运算"))
                {
                    color_black_hat(sender, e);
                }
            }
        }








        //二值图像的膨胀函数？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void BinaryDilation()//二值图像的膨胀函数(膨胀白色)  
        {
            int target;
            int target_binary;
            if (int.TryParse(textBox_structureElementValue.Text, out target))
            {
                if (target % 2 != 0)//奇数
                {
                    // 转换成功，可以使用 target 变量和 target_binary 变量进行后续操作
                    target = int.Parse(textBox_structureElementValue.Text); // 均值
                    target_binary = target / 2;
                }
                else
                {
                    // 转换失败，弹窗提示报错
                    MessageBox.Show("请输入奇数", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

            }
            else
            {
                // 转换失败，弹窗提示报错
                MessageBox.Show("输入的文本不是有效的数字", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            int R;

            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    R = bt1.GetPixel(i, j).R;
                    if (R == 255)//是白色
                    {
                        for (int k = -target_binary; k <= target_binary; k++)//以i,j为中心点
                        {
                            for (int l = -target_binary; l <= target_binary; l++)
                            {
                                if (i + k >= 0 && i + k < bt1.Width &&
                                   j + l >= 0 && j + l < bt1.Height)
                                {
                                    bt2.SetPixel(i + k, j + l, Color.FromArgb(255, 255, 255));
                                }

                            }
                        }
                    }
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }
        }

        //二值图像腐蚀
        private void BinaryErosion()//二值图像的腐蚀函数(腐蚀白色)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);

            int target;//SE大小
            int target_binary;
            if (int.TryParse(textBox_structureElementValue.Text, out target))
            {
                if (target % 2 != 0)//奇数
                {
                    // 转换成功，可以使用 target 变量和 target_binary 变量进行后续操作
                    target = int.Parse(textBox_structureElementValue.Text); // 均值
                    target_binary = target / 2;
                }
                else
                {
                    // 转换失败，弹窗提示报错
                    MessageBox.Show("请输入奇数值", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                // 转换失败，弹窗提示报错
                MessageBox.Show("输入的文本不是有效的数字", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 创建11x11的全1模板
            int[,] se = new int[target, target];
            for (int i = 0; i < target; i++)
            {
                for (int j = 0; j < target; j++)
                {
                    se[i, j] = 1;
                }
            }

            // 获取图像的宽度和高度
            int width = bt1.Width;
            int height = bt1.Height;

            // 创建新的Bitmap对象用于保存处理后的图像
            Bitmap resultImage = new Bitmap(width, height);

            // 遍历图像的每个像素点
            for (int i = target_binary; i < width - target_binary; i++)
            {
                for (int j = target_binary; j < height - target_binary; j++)
                {
                    bool erode = true;

                    // 检查结构元素是否与周围像素匹配
                    for (int k = -target_binary; k <= target_binary; k++)
                    {
                        for (int l = -target_binary; l <= target_binary; l++)
                        {
                            // 若结构元素与周围像素不匹配，则不进行腐蚀操作
                            if (se[k + target_binary, l + target_binary] == 1 && bt1.GetPixel(i + k, j + l).R != 255)//有黑色部分
                            {
                                erode = false;
                                break;
                            }
                        }
                        if (!erode)
                        {
                            break;
                        }
                    }

                    // 如果结构元素与周围像素匹配，则将该像素设置为白色
                    if (erode)
                    {
                        resultImage.SetPixel(i, j, Color.White);
                    }
                    else//否则设置为黑色
                    {
                        resultImage.SetPixel(i, j, Color.Black);
                    }

                    //pictureBox_show.Refresh();
                }
            }

            // 处理图像边界
            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < target_binary; j++)
                {
                    resultImage.SetPixel(i, j, Color.Black);
                    resultImage.SetPixel(i, height - j - 1, Color.Black);
                }
            }
            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < target_binary; i++)
                {
                    resultImage.SetPixel(i, j, Color.Black);
                    resultImage.SetPixel(width - i - 1, j, Color.Black);
                }
            }

            // 显示处理后的图像
            pictureBox_show.Image = resultImage;
        }

        //二值图像的边缘提取
        private void binary_handle_change_边缘提取(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            Bitmap originalBt = new Bitmap(original_image.Image);
            BinaryErosion(); //先腐蚀
            bt1 = new Bitmap(pictureBox_show.Image);
            int R1, R2, R3;
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    R1 = bt1.GetPixel(i, j).R;
                    R2 = originalBt.GetPixel(i, j).R;
                    R3 = (R2 - R1) > 0 ? (R2 - R1) : (R1 - R2);
                    bt2.SetPixel(i, j, Color.FromArgb(R3, R3, R3));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }
        }
        //二值图像的顶帽运算
        private void binary_top_hat(object sender, EventArgs e)
        {
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            Bitmap originalBt = new Bitmap(pictureBox_show.Image);//原始图像
                                                                  //执行开运算，先腐蚀，再开启
            BinaryErosion();
            BinaryDilation();
            Bitmap bt_open = new Bitmap(pictureBox_show.Image);//获取开运算之后的图像
                                                               // 循环遍历图像的每个像素
            int R1, R2, R3;
            for (int i = 0; i < bt_open.Width; i++)
            {
                for (int j = 0; j < bt_open.Height; j++)
                {
                    R1 = bt_open.GetPixel(i, j).R; // 获取顶帽图像的像素值
                    R2 = originalBt.GetPixel(i, j).R;// 获取原图像的像素值
                    R3 = (R2 - R1) > 0 ? (R2 - R1) : (R1 - R2);
                    bt2.SetPixel(i, j, Color.FromArgb(R3, R3, R3));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }

        }

        //二值图像的黑帽运算
        private void binary_black_hat(object sender, EventArgs e)
        {
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            Bitmap originalBt = new Bitmap(pictureBox_show.Image);//原始图像

            BinaryDilation();//执行闭运算，先开启，再腐蚀
            BinaryErosion();


            Bitmap bt_close = new Bitmap(pictureBox_show.Image);//获取开运算之后的图像
                                                                // 循环遍历图像的每个像素
            int R1, R2, R3;
            for (int i = 0; i < bt_close.Width; i++)
            {
                for (int j = 0; j < bt_close.Height; j++)
                {
                    R1 = bt_close.GetPixel(i, j).R; // 获取黑帽图像的像素值
                    R2 = originalBt.GetPixel(i, j).R;// 获取原图像的像素值
                    R3 = (R2 - R1) > 0 ? (R2 - R1) : (R1 - R2);
                    bt2.SetPixel(i, j, Color.FromArgb(R3, R3, R3));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }
        }


        //彩色图像的黑帽运算
        private void color_black_hat(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap originalBt = new Bitmap(pictureBox_show.Image);//原始图像

            ColorDilation();//执行闭运算，先开启，再腐蚀
            ColorErosion();


            Bitmap bt_close = new Bitmap(pictureBox_show.Image);//获取开运算之后的图像
                                                                // 循环遍历图像的每个像素
            int R1, R2, R3;
            for (int i = 0; i < bt_close.Width; i++)
            {
                for (int j = 0; j < bt_close.Height; j++)
                {
                    Color color1 = originalBt.GetPixel(i, j);
                    Color color2 = bt_close.GetPixel(i, j);
                    int diffR = Math.Abs(color2.R - color1.R);
                    int diffG = Math.Abs(color2.G - color1.G);
                    int diffB = Math.Abs(color2.B - color1.B);
                    bt1.SetPixel(i, j, Color.FromArgb(diffR, diffG, diffB));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt1;
            }
        }
        //彩色图像的顶帽运算
        private void color_top_hat(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap originalBt = new Bitmap(pictureBox_show.Image);//原始图像
                                                                  //执行开运算，先腐蚀，再开启
            ColorErosion();
            ColorDilation();
            Bitmap bt_open = new Bitmap(pictureBox_show.Image);//获取开运算之后的图像
                                                               // 循环遍历图像的每个像素
            int R1, R2, R3;
            for (int i = 0; i < bt_open.Width; i++)
            {
                for (int j = 0; j < bt_open.Height; j++)
                {
                    Color color1 = originalBt.GetPixel(i, j);
                    Color color2 = bt_open.GetPixel(i, j);
                    int diffR = Math.Abs(color2.R - color1.R);
                    int diffG = Math.Abs(color2.G - color1.G);
                    int diffB = Math.Abs(color2.B - color1.B);
                    bt1.SetPixel(i, j, Color.FromArgb(diffR, diffG, diffB));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt1;
            }
        }
        //彩色图像的边缘提取
        private void color_handle_change_边缘提取(object sender, EventArgs e)
        {
            Bitmap bt1;
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            Bitmap originalBt = new Bitmap(original_image.Image);
            ColorErosion();//先腐蚀
            bt1 = new Bitmap(pictureBox_show.Image);
            for (int i = 0; i < bt1.Width; i++)
            {
                for (int j = 0; j < bt1.Height; j++)
                {
                    Color color1 = bt1.GetPixel(i, j);
                    Color color2 = originalBt.GetPixel(i, j);
                    int diffR = Math.Abs(color2.R - color1.R);
                    int diffG = Math.Abs(color2.G - color1.G);
                    int diffB = Math.Abs(color2.B - color1.B);
                    bt2.SetPixel(i, j, Color.FromArgb(diffR, diffG, diffB));
                }
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = bt2;
            }



        }

        private void btnBinaryChangeadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnBinaryChangeadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnBinaryChangeadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnBinaryChangeadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }





        //添加高斯噪声的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnGaussianadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            //Bitmap bt1 = new Bitmap(original_image.Image);
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);

            double mean;// 均值
            double standardDeviation; // 标准差，控制噪声强度
            if (double.TryParse(textBox_gaussianAvg.Text, out mean) &&
                double.TryParse(textBox_gaussianVariance.Text, out standardDeviation))
            {
                // 转换成功，可以使用 mean 变量和 standardDeviation 变量进行后续操作
                mean = double.Parse(textBox_gaussianAvg.Text); // 均值
                standardDeviation = double.Parse(textBox_gaussianVariance.Text);
                Bitmap noisyImage = AddGaussianNoise(bt1, mean, standardDeviation);
                pictureBox_show.Refresh();//刷新图片框
                pictureBox_show.Image = noisyImage;
            }
            else
            {
                // 转换失败，弹窗提示报错
                MessageBox.Show("输入的文本不是有效的数字", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public static double NextGaussian(Random random, double mean, double standardDeviation)
        {
            double u1 = 1.0 - random.NextDouble();
            double u2 = 1.0 - random.NextDouble();
            double randStdNormal = Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Sin(2.0 * Math.PI * u2);
            double randNormal = mean + standardDeviation * randStdNormal;
            return randNormal;
        }
        public static Bitmap AddGaussianNoise(Bitmap image, double mean, double standardDeviation)
        {
            Random random = new Random();
            Bitmap result = new Bitmap(image.Width, image.Height);

            for (int x = 0; x < image.Width; x++)
            {
                for (int y = 0; y < image.Height; y++)
                {
                    Color pixel = image.GetPixel(x, y);
                    double gaussian = NextGaussian(random, mean, standardDeviation);

                    int red = (int)(pixel.R + gaussian);
                    int green = (int)(pixel.G + gaussian);
                    int blue = (int)(pixel.B + gaussian);

                    red = Math.Max(0, Math.Min(255, red));
                    green = Math.Max(0, Math.Min(255, green));
                    blue = Math.Max(0, Math.Min(255, blue));

                    Color noisyPixel = Color.FromArgb(pixel.A, red, green, blue);
                    result.SetPixel(x, y, noisyPixel);
                }
            }

            return result;

        }
        private void btnGaussianadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnGaussianadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnGaussianadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnGaussianadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }
        //private void trackBar_gaussianNoise_Scroll(object sender, EventArgs e)
        //{
        //    //拉动 高斯噪声 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为 高斯噪声 的调节值
        //    textBox_showGaussianNoise.Text = trackBar_gaussianNoise.Value.ToString() + "%";
        //}


        //添加椒盐噪声的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnImpulseadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            //Bitmap bt2 = new Bitmap(original_image.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);

            // 添加椒盐噪声
            //double noiseProbability = 0.05; // 噪声概率，控制噪声密度
            double noiseProbability = 1.0 * trackBar_impulseNoise.Value / 100; ; // 噪声概率，控制噪声密度
                                                                                 //Bitmap noisyImage = AddSaltAndPepperNoise(bt2, noiseProbability);
            Bitmap noisyImage = ImageNoiseGenerator.AddSaltAndPepperNoise(bt2, noiseProbability);
            ////刷新图片框
            pictureBox_show.Refresh();
            pictureBox_show.Image = noisyImage;

        }


        private void trackBar_impulseNoise_Scroll(object sender, EventArgs e)
        {
            //拉动 椒盐噪声 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为 高斯噪声 的调节值
            textBox_showImpulseNoise.Text = (1.0 * (trackBar_impulseNoise.Value)).ToString() + "%";//噪声比例为百分数
        }
        private void btnImpulseadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnImpulseadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnImpulseadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnImpulseadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }


        //图像放大的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_magnify_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;

            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            imageZoom imageZoom = new imageZoom();
            imageZoom.pictureBox.Image = bt1;
            imageZoom.ShowDialog();

        }
        private void btn_magnify_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_magnify.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_zoom_press.png");
        }
        private void btn_magnify_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_magnify.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_zoom.png");
        }

        //图像缩小的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_reduce_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;


            int k = 2; //定义图像缩小的倍数
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Width / k, pictureBox_show.Height / k);
            int Red, Green, Blue;
            for (int i = 0; i < bt1.Width - 1; i++)
            {
                for (int j = 0; j < bt1.Height - 1; j++)
                {
                    Red = bt1.GetPixel(i, j).R;
                    Green = bt1.GetPixel(i, j).G;
                    Blue = bt1.GetPixel(i, j).B;
                    bt2.SetPixel((int)(i / k), (int)(j / k), Color.FromArgb(Red, Green, Blue));
                }
                pictureBox_show.Refresh();//另外建立了一个图片框用于显示处理后的图像
                pictureBox_show.Image = bt2;
            }

        }



        //图像旋转的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnSpinadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            Bitmap bt1 = new Bitmap(original_image.Image);
            double angle = 1.0 * trackBar_spin.Value;
            //double angle = 1.0 *textBox_showSpin.;
            Bitmap bt2 = new Bitmap(original_image.Image);
            if (Rotation(bt1, angle, out bt2))
            {
                pictureBox_show.Image = bt2;
            }
            else
            {
                return;
            }

        }

        private void trackBar_spin_Scroll(object sender, EventArgs e)
        {
            //拉动 旋转 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为二值化的调节值
            textBox_showSpin.Text = trackBar_spin.Value.ToString() + "度";
        }
        private void btnSpinadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnSpinadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnSpinadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnSpinadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }
        /// <summary>
        /// 图像旋转
        /// </summary>
        /// <param name="srcBmp">原始图像</param>
        /// <param name="degree">旋转角度</param>
        /// <param name="dstBmp">目标图像</param>
        /// <returns>处理成功 true 失败 false</returns>
        public static bool Rotation(Bitmap srcBmp, double degree, out Bitmap dstBmp)
        {
            if (srcBmp == null)
            {
                dstBmp = null;
                return false;
            }
            dstBmp = null;
            BitmapData srcBmpData = null;
            BitmapData dstBmpData = null;


            double radian = degree * Math.PI / 180.0;//将角度转换为弧度
                                                     //计算正弦和余弦
            double sin = Math.Sin(radian);
            double cos = Math.Cos(radian);

            //计算旋转后的图像大小
            int widthDst = (int)(srcBmp.Height * Math.Abs(sin) + srcBmp.Width * Math.Abs(cos));
            int heightDst = (int)(srcBmp.Width * Math.Abs(sin) + srcBmp.Height * Math.Abs(cos));

            dstBmp = new Bitmap(widthDst, heightDst);
            //确定旋转点
            int dx = (int)(srcBmp.Width / 2 * (1 - cos) + srcBmp.Height / 2 * sin);
            int dy = (int)(srcBmp.Width / 2 * (0 - sin) + srcBmp.Height / 2 * (1 - cos));

            int insertBeginX = srcBmp.Width / 2 - widthDst / 2;
            int insertBeginY = srcBmp.Height / 2 - heightDst / 2;

            //插值公式所需参数
            double ku = insertBeginX * cos - insertBeginY * sin + dx;
            double kv = insertBeginX * sin + insertBeginY * cos + dy;
            double cu1 = cos, cu2 = sin;
            double cv1 = sin, cv2 = cos;

            double fu, fv, a, b, F1, F2;
            int Iu, Iv;
            srcBmpData = srcBmp.LockBits(new Rectangle(0, 0, srcBmp.Width, srcBmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            dstBmpData = dstBmp.LockBits(new Rectangle(0, 0, dstBmp.Width, dstBmp.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);

            unsafe
            {
                byte* ptrSrc = (byte*)srcBmpData.Scan0;
                byte* ptrDst = (byte*)dstBmpData.Scan0;
                for (int i = 0; i < heightDst; i++)
                {
                    for (int j = 0; j < widthDst; j++)
                    {
                        fu = j * cu1 - i * cu2 + ku;
                        fv = j * cv1 + i * cv2 + kv;
                        if ((fv < 1) || (fv > srcBmp.Height - 1) || (fu < 1) || (fu > srcBmp.Width - 1))
                        {

                            ptrDst[i * dstBmpData.Stride + j * 3] = 150;
                            ptrDst[i * dstBmpData.Stride + j * 3 + 1] = 150;
                            ptrDst[i * dstBmpData.Stride + j * 3 + 2] = 150;
                        }
                        else
                        {//双线性插值
                            Iu = (int)fu;
                            Iv = (int)fv;
                            a = fu - Iu;
                            b = fv - Iv;
                            for (int k = 0; k < 3; k++)
                            {
                                F1 = (1 - b) * *(ptrSrc + Iv * srcBmpData.Stride + Iu * 3 + k) + b * *(ptrSrc + (Iv + 1) * srcBmpData.Stride + Iu * 3 + k);
                                F2 = (1 - b) * *(ptrSrc + Iv * srcBmpData.Stride + (Iu + 1) * 3 + k) + b * *(ptrSrc + (Iv + 1) * srcBmpData.Stride + (Iu + 1) * 3 + k);
                                *(ptrDst + i * dstBmpData.Stride + j * 3 + k) = (byte)((1 - a) * F1 + a * F2);
                            }
                        }
                    }
                }
            }
            srcBmp.UnlockBits(srcBmpData);
            dstBmp.UnlockBits(dstBmpData);
            return true;
        }

        //添加随机噪声的确定按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btnRandomadjust_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            //Bitmap bt2 = new Bitmap(original_image.Image);
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            int noiseProbability = trackBar_RandomNoise.Value;//噪声概率
            Random random = new Random();

            for (int i = 0; i < bt2.Width; i++)
            {
                for (int j = 0; j < bt2.Height; j++)
                {
                    Color pixel = bt2.GetPixel(i, j);

                    int noise = random.Next(-noiseProbability, noiseProbability + 1);

                    int red = Clamp(pixel.R + noise, 0, 255);
                    int green = Clamp(pixel.G + noise, 0, 255);
                    int blue = Clamp(pixel.B + noise, 0, 255);

                    Color newPixel = Color.FromArgb(red, green, blue);
                    bt2.SetPixel(i, j, newPixel);
                }
            }


            pictureBox_show.Refresh();
            pictureBox_show.Image = bt2;

        }
        private int Clamp(int value, int min, int max)
        {
            if (value < min)
                return min;
            if (value > max)
                return max;
            return value;
        }

        private void trackBar_RandomNoise_Scroll(object sender, EventArgs e)
        {
            //拉动 随机噪声 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为 高斯噪声 的调节值
            textBox_showRandomNoise.Text = (1.0 * trackBar_RandomNoise.Value).ToString();//噪声比例为百分数

        }


        private void btnRandomadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnRandomadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnRandomadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnRandomadjust.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }

        //伪彩色处理的按钮
        private void btnWeiCaiSe_Click(object sender, EventArgs e)
        {
            if (!judge_pb_img_exit()) return;
            Bitmap origin = new Bitmap(pictureBox_show.Image);
            Bitmap change = new Bitmap(pictureBox_show.Image);
            string value = comboBox_WeiCaiSeCollect.Text.ToString();
            if (value.Equals("彩虹色带映射"))
            {
                change = PseudoColorImageBuilder.PGrayToPseudoColor2(origin, 2);
            }
            else if (value.Equals("铁红色带映射"))
            {
                change = PseudoColorImageBuilder.PGrayToPseudoColor2(origin, 1);
            }
            else if (value.Equals("灰度级-彩色变换法"))
            {
                change = weicaise_chuli(origin);
            }
            pictureBox_show.Refresh();
            pictureBox_show.Image = change;
        }

        private void btnWeiCaiSe_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnWeiCaiSe.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }
        private void btnWeiCaiSe_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btnWeiCaiSe.BackgroundImage = new Bitmap("D:\\AllFile\\DeskTop\\计算机视觉\\btn_img\\btn_confirm.png");
        }


        //灰度级-彩色变换法
        private Bitmap weicaise_chuli(Bitmap src)
        {
            Bitmap bt2 = new Bitmap(pictureBox_show.Image);
            Bitmap bt1 = new Bitmap(pictureBox_show.Image);
            Bitmap show_bt = new Bitmap(pictureBox_show.Image);
            for (int i = 0; i < bt2.Width; i++)
            {
                for (int j = 0; j < bt2.Height; j++)
                {
                    Color c = bt1.GetPixel(i, j);
                    int R = c.R; int G = c.G; int B = c.B;
                    byte temp = (byte)(B * 0.114 + G * 0.587 + R * 0.299);
                    if (temp >= 0 && temp <= 63)
                    {
                        show_bt.SetPixel(i, j, Color.FromArgb(0, (byte)(4 * temp), (byte)255));
                    }
                    if (temp >= 64 && temp <= 127)
                    {
                        show_bt.SetPixel(i, j, Color.FromArgb(0, 255, (byte)(510 - 4 * temp)));
                    }
                    if (temp >= 128 && temp <= 191)
                    {
                        show_bt.SetPixel(i, j, Color.FromArgb((byte)(4 * temp - 510), 255, 0));
                    }
                    if (temp >= 192 && temp <= 255)
                    {
                        show_bt.SetPixel(i, j, Color.FromArgb(255, (byte)(1022 - 4 * temp), 0));
                    }
                }
            }
            return show_bt;
        }

        //灰度分层法
        private Bitmap WeicaiseChuli(Bitmap src, int numLevels)
        {
            if (numLevels <= 0 || numLevels > 256)
            {
                throw new ArgumentException("Invalid number of levels. Must be between 1 and 256.");
            }

            Bitmap pseudoColorImage = new Bitmap(src.Width, src.Height);

            // 计算每个灰度层的宽度
            int levelWidth = 256 / numLevels;

            // 定义颜色映射表
            Color[] colorMap = new Color[256];

            // 设置颜色映射表
            for (int i = 0; i < 256; i++)
            {
                // 计算当前灰度级别所在的层数
                int level = i / levelWidth;

                // 计算当前层内的灰度偏移量
                int offset = (levelWidth / (numLevels - 1)) * (i % levelWidth);

                // 根据层数和偏移量计算伪彩色
                byte red = (byte)(level * (255 / (numLevels - 1)));
                byte green = (byte)((numLevels - 1 - level) * (255 / (numLevels - 1)));
                byte blue = (byte)offset;

                colorMap[i] = Color.FromArgb(red, green, blue);
            }

            // 遍历灰度图像的每个像素
            for (int x = 0; x < src.Width; x++)
            {
                for (int y = 0; y < src.Height; y++)
                {
                    Color pixelColor = src.GetPixel(x, y);
                    int grayLevel = (int)(pixelColor.R * 0.299 + pixelColor.G * 0.587 + pixelColor.B * 0.114);

                    // 根据灰度级别选择对应的伪彩色
                    pseudoColorImage.SetPixel(x, y, colorMap[grayLevel]);
                }
            }

            return pseudoColorImage;
        }

        private void trackBar_grayLevel_Scroll(object sender, EventArgs e)
        {
            //拉动 灰度分层的 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示，作为二值化的调节值
            textBox_showGrayLevel.Text = trackBar_grayLevel.Value.ToString();
        }

        private void btn_GrayLevel_Click(object sender, EventArgs e)
        {
            Bitmap bt1 = new Bitmap(original_image.Image);
            int grayLevelValue = trackBar_grayLevel.Value;//灰度分层数
            Bitmap change = WeicaiseChuli(bt1, grayLevelValue);
            pictureBox_show.Refresh();
            pictureBox_show.Image = change;
        }
    }



    public class ImageNoiseGenerator
    {
        //添加椒盐噪声
        public static Bitmap AddSaltAndPepperNoise(Bitmap image, double noiseRatio)
        {
            Bitmap noisyImage = new Bitmap(image);

            int width = noisyImage.Width;
            int height = noisyImage.Height;
            int totalPixels = width * height;
            int noisePixels = (int)(noiseRatio * totalPixels);

            Random random = new Random();

            for (int i = 0; i < noisePixels; i++)
            {
                int x = random.Next(width);
                int y = random.Next(height);

                Color randomColor = random.Next(2) == 0 ? Color.Black : Color.White;
                noisyImage.SetPixel(x, y, randomColor);
            }

            return noisyImage;
        }


        //添加随机噪声
        public static Bitmap AddRandomNoise(Bitmap image, double noisePercentage)
        {

            // 创建一个新的Bitmap对象来存储添加噪声后的图像
            Bitmap noisyImage = new Bitmap(image.Width, image.Height);

            // 将image复制到noisyImage
            using (Graphics g = Graphics.FromImage(noisyImage))
            {
                g.DrawImage(image, 0, 0, image.Width, image.Height);
            }

            // 计算要添加噪声的像素数
            int noisePixels = (int)(noisePercentage * image.Width * image.Height / 100.0);

            // 创建一个随机数生成器
            Random random = new Random();

            // 遍历要添加噪声的像素数
            for (int i = 0; i < noisePixels; i++)
            {
                // 生成随机的噪声像素的坐标
                int x = random.Next(0, image.Width);
                int y = random.Next(0, image.Height);

                // 生成随机的噪声像素的颜色
                Color noiseColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));

                // 将噪声像素的颜色设置到noisyImage中对应的像素
                noisyImage.SetPixel(x, y, noiseColor);
            }

            return noisyImage;
        }













    }

    /// <summary>
    /// 伪彩色图像构造器
    /// </summary>
    public class PseudoColorImageBuilder
    {
        /// <summary>
        /// 铁红色带映射表
        /// 每一行代表一个彩色分类，存放顺序是RGB
        /// </summary>
        public static byte[,] ironTable = new byte[128, 3] {
                {0,   0,  0},
                {0,   0,  0},
                {0,   0,  36},
                {0,   0,  51},
                {0,   0,  66},
                {0,   0,  81},
                {2,   0,  90},
                {4,   0,  99},
                {7,   0, 106},
                {11,   0, 115},
                {14,   0, 119},
                {20,   0, 123},
                {27,   0, 128},
                {33,   0, 133},
                {41,   0, 137},
                {48,   0, 140},
                {55,   0, 143},
                {61,   0, 146},
                {66,   0, 149},
                {72,   0, 150},
                {78,   0, 151},
                {84,   0, 152},
                {91,   0, 153},
                {97,   0, 155},
                {104,   0, 155},
                {110,   0, 156},
                {115,   0, 157},
                {122,   0, 157},
                {128,   0, 157},
                {134,   0, 157},
                {139,   0, 157},
                {146,   0, 156},
                {152,   0, 155},
                {157,   0, 155},
                {162,   0, 155},
                {167,   0, 154},
                {171,   0, 153},
                {175,   1, 152},
                {178,   1, 151},
                {182,   2, 149},
                {185,   4, 149},
                {188,   5, 147},
                {191,   6, 146},
                {193,   8, 144},
                {195,  11, 142},
                {198,  13, 139},
                {201,  17, 135},
                {203,  20, 132},
                {206,  23, 127},
                {208,  26, 121},
                {210,  29, 116},
                {212,  33, 111},
                {214,  37, 103},
                {217,  41,  97},
                {219,  46,  89},
                {221,  49,  78},
                {223,  53,  66},
                {224,  56,  54},
                {226,  60,  42},
                {228,  64,  30},
                {229,  68,  25},
                {231,  72,  20},
                {232,  76,  16},
                {234,  78,  12},
                {235,  82,  10},
                {236,  86,   8},
                {237,  90,   7},
                {238,  93,   5},
                {239,  96,   4},
                {240, 100,   3},
                {241, 103,   3},
                {241, 106,   2},
                {242, 109,   1},
                {243, 113,   1},
                {244, 116,   0},
                {244, 120,   0},
                {245, 125,   0},
                {246, 129,   0},
                {247, 133,   0},
                {248, 136,   0},
                {248, 139,   0},
                {249, 142,   0},
                {249, 145,   0},
                {250, 149,   0},
                {251, 154,   0},
                {252, 159,   0},
                {253, 163,   0},
                {253, 168,   0},
                {253, 172,   0},
                {254, 176,   0},
                {254, 179,   0},
                {254, 184,   0},
                {254, 187,   0},
                {254, 191,   0},
                {254, 195,   0},
                {254, 199,   0},
                {254, 202,   1},
                {254, 205,   2},
                {254, 208,   5},
                {254, 212,   9},
                {254, 216,  12},
                {255, 219,  15},
                {255, 221,  23},
                {255, 224,  32},
                {255, 227,  39},
                {255, 229,  50},
                {255, 232,  63},
                {255, 235,  75},
                {255, 238,  88},
                {255, 239, 102},
                {255, 241, 116},
                {255, 242, 134},
                {255, 244, 149},
                {255, 245, 164},
                {255, 247, 179},
                {255, 248, 192},
                {255, 249, 203},
                {255, 251, 216},
                {255, 253, 228},
                {255, 254, 239},
                {255, 255, 249},
                {255, 255, 249},
                {255, 255, 249},
                {255, 255, 249},
                {255, 255, 249},
                {255, 255, 249},
                {255, 255, 249},
                {255, 255, 249} };

        /// <summary>
        /// 彩虹色带映射表
        /// </summary>
        public static byte[,] rainTable = new byte[128, 3] {
            {0,   0,   0},
            {0,   0,   0},
            {15,   0,  15},
            {31,   0,  31},
            {47,   0,  47},
            {63,   0,  63},
            {79,   0,  79},
            {95,   0,  95},
            {111,   0, 111},
            {127,   0, 127},
            {143,   0, 143},
            {159,   0, 159},
            {175,   0, 175},
            {191,   0, 191},
            {207,   0, 207},
            {223,   0, 223},
            {239,   0, 239},
            {255,   0, 255},
            {239,   0, 250},
            {223,   0, 245},
            {207,   0, 240},
            {191,   0, 236},
            {175,   0, 231},
            {159,   0, 226},
            {143,   0, 222},
            {127,   0, 217},
            {111,   0, 212},
            {95,   0, 208},
            {79,   0, 203},
            {63,   0, 198},
            {47,   0, 194},
            {31,   0, 189},
            {15,   0, 184},
            {0,   0, 180},
            {0,  15, 184},
            {0,  31, 189},
            {0,  47, 194},
            {0,  63, 198},
            {0,  79, 203},
            {0,  95, 208},
            {0, 111, 212},
            {0, 127, 217},
            {0, 143, 222},
            {0, 159, 226},
            {0, 175, 231},
            {0, 191, 236},
            {0, 207, 240},
            {0, 223, 245},
            {0, 239, 250},
            {0, 255, 255},
            {0, 245, 239},
            {0, 236, 223},
            {0, 227, 207},
            {0, 218, 191},
            {0, 209, 175},
            {0, 200, 159},
            {0, 191, 143},
            {0, 182, 127},
            {0, 173, 111},
            {0, 164,  95},
            {0, 155,  79},
            {0, 146,  63},
            {0, 137,  47},
            {0, 128,  31},
            {0, 119,  15},
            {0, 110,   0},
            {15, 118,   0},
            {30, 127,   0},
            {45, 135,   0},
            {60, 144,   0},
            {75, 152,   0},
            {90, 161,   0},
            {105, 169,  0},
            {120, 178,  0},
            {135, 186,  0},
            {150, 195,  0},
            {165, 203,  0},
            {180, 212,  0},
            {195, 220,  0},
            {210, 229,  0},
            {225, 237,  0},
            {240, 246,  0},
            {255, 255,  0},
            {251, 240,  0},
            {248, 225,  0},
            {245, 210,  0},
            {242, 195,  0},
            {238, 180,  0},
            {235, 165,  0},
            {232, 150,  0},
            {229, 135,  0},
            {225, 120,  0},
            {222, 105,  0},
            {219,  90,  0},
            {216,  75,  0},
            {212,  60,  0},
            {209,  45,  0},
            {206,  30,  0},
            {203,  15,  0},
            {200,   0,  0},
            {202,  11,  11},
            {205,  23,  23},
            {207,  34,  34},
            {210,  46,  46},
            {212,  57,  57},
            {215,  69,  69},
            {217,  81,  81},
            {220,  92,  92},
            {222, 104, 104},
            {225, 115, 115},
            {227, 127, 127},
            {230, 139, 139},
            {232, 150, 150},
            {235, 162, 162},
            {237, 173, 173},
            {240, 185, 185},
            {242, 197, 197},
            {245, 208, 208},
            {247, 220, 220},
            {250, 231, 231},
            {252, 243, 243},
            {252, 243, 243},
            {252, 243, 243},
            {252, 243, 243},
            {252, 243, 243},
            {252, 243, 243},
            {252, 243, 243},
            {252, 243, 243}
        };


        /// <summary>
        /// 灰度图转伪彩色图像函数（通过映射规则计算的方法）
        /// </summary>
        /// <param name="src">24位灰度图</param>
        /// <returns>返回构造的伪彩色图像</returns>
        public static Bitmap PGrayToPseudoColor1(Bitmap src)
        {
            try
            {
                Bitmap a = new Bitmap(src);

                Rectangle rect = new Rectangle(0, 0, a.Width, a.Height);
                System.Drawing.Imaging.BitmapData bmpData = a.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                int stride = bmpData.Stride;
                unsafe
                {
                    byte* pIn = (byte*)bmpData.Scan0.ToPointer();
                    byte* P;
                    int R, G, B;
                    int temp = 0;

                    for (int y = 0; y < a.Height; y++)
                    {
                        for (int x = 0; x < a.Width; x++)
                        {
                            P = pIn;
                            B = P[0];
                            G = P[1];
                            R = P[2];

                            temp = (byte)(B * 0.114 + G * 0.587 + R * 0.299);
                            if (temp >= 0 && temp <= 63)
                            {
                                P[2] = 0;
                                P[1] = (byte)(254 - 4 * temp);
                                P[0] = (byte)255;
                            }
                            if (temp >= 64 && temp <= 127)
                            {
                                P[2] = 0;
                                P[1] = (byte)(4 * temp - 254);
                                P[0] = (byte)(510 - 4 * temp);
                            }
                            if (temp >= 128 && temp <= 191)
                            {
                                P[2] = (byte)(4 * temp - 510);
                                P[1] = (byte)(255);
                                P[0] = (byte)0;
                            }
                            if (temp >= 192 && temp <= 255)
                            {
                                P[2] = (byte)255;
                                P[1] = (byte)(1022 - 4 * temp);
                                P[0] = (byte)0;
                            }
                            pIn += 3;
                        }
                        pIn += stride - a.Width * 3;
                    }
                }
                a.UnlockBits(bmpData);
                return a;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message.ToString());
                return null;
            }
        }


        /// <summary>
        /// 灰度图转伪彩色图像函数（通过查表的方法）
        /// </summary>
        /// <param name="src"></param>
        /// <param name="type">转换类型（1.使用铁红  2.使用彩虹）</param>
        /// <returns></returns>
        public static Bitmap PGrayToPseudoColor2(Bitmap src, int type)
        {
            try
            {
                if (type == 1)
                {
                    Bitmap a = new Bitmap(src); // 创建一个与源图像大小相同的新位图
                    Rectangle rect = new Rectangle(0, 0, a.Width, a.Height);
                    System.Drawing.Imaging.BitmapData bmpData = a.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                    int stride = bmpData.Stride; // 位图每行的字节数
                    unsafe
                    {
                        byte* pIn = (byte*)bmpData.Scan0.ToPointer(); // 指向位图数据的指针
                        int temp;
                        byte R, G, B;

                        for (int y = 0; y < a.Height; y++)
                        {
                            for (int x = 0; x < a.Width; x++)
                            {
                                temp = pIn[0] / 2; // 计算颜色查找表的索引

                                R = ironTable[temp, 0]; // 从铁红色带表中查找红色分量
                                G = ironTable[temp, 1]; // 从铁红色带表中查找绿色分量
                                B = ironTable[temp, 2]; // 从铁红色带表中查找蓝色分量

                                pIn[0] = B; // 设置像素的蓝色分量
                                pIn[1] = G; // 设置像素的绿色分量
                                pIn[2] = R; // 设置像素的红色分量

                                pIn += 3; // 移动指针到下一个像素
                            }
                            pIn += stride - a.Width * 3; // 移动指针到下一行的起始位置
                        }
                    }
                    a.UnlockBits(bmpData); // 释放对位图数据的锁定
                    return a; // 返回转换后的位图
                }
                else if (type == 2)
                {
                    Bitmap a = new Bitmap(src); // 创建一个与源图像大小相同的新位图
                    Rectangle rect = new Rectangle(0, 0, a.Width, a.Height);
                    System.Drawing.Imaging.BitmapData bmpData = a.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                    int stride = bmpData.Stride; // 位图每行的字节数
                    unsafe
                    {
                        byte* pIn = (byte*)bmpData.Scan0.ToPointer(); // 指向位图数据的指针
                        int temp;
                        byte R, G, B;

                        for (int y = 0; y < a.Height; y++)
                        {
                            for (int x = 0; x < a.Width; x++)
                            {
                                temp = pIn[0] / 2; // 计算颜色查找表的索引

                                R = rainTable[temp, 0]; // 从彩虹色带表中查找红色分量
                                G = rainTable[temp, 1]; // 从彩虹色带表中查找绿色分量
                                B = rainTable[temp, 2]; // 从彩虹色带表中查找蓝色分量

                                pIn[0] = B; // 设置像素的蓝色分量
                                pIn[1] = G; // 设置像素的绿色分量
                                pIn[2] = R; // 设置像素的红色分量

                                pIn += 3; // 移动指针到下一个像素
                            }
                            pIn += stride - a.Width * 3; // 移动指针到下一行的起始位置
                        }
                    }
                    a.UnlockBits(bmpData); // 释放对位图数据的锁定
                    return a; // 返回转换后的位图
                }
                else
                {
                    throw new Exception("type 参数不合法！"); // 对于无效的 type 参数，抛出异常
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message.ToString()); // 显示包含异常消息的错误消息框
                return null; // 如果发生异常，返回 null
            }
        }
    }

}




