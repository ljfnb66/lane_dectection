﻿//using System.ComponentModel;
//using System.Drawing.Drawing2D;
//using System.Drawing;
//using System;

//namespace imageIdentification
//{
//    partial class Form1
//    {
//        /// <summary>
//        /// 必需的设计器变量。
//        /// </summary>
//        private System.ComponentModel.IContainer components = null;

//        /// <summary>
//        /// 清理所有正在使用的资源。
//        /// </summary>
//        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
//        protected override void Dispose(bool disposing)
//        {
//            if (disposing && (components != null))
//            {
//                components.Dispose();
//            }
//            base.Dispose(disposing);
//        }

//        #region Windows 窗体设计器生成的代码

//        /// <summary>
//        /// 设计器支持所需的方法 - 不要修改
//        /// 使用代码编辑器修改此方法的内容。
//        /// </summary>
//        private void InitializeComponent()
//        {
//            this.button1 = new System.Windows.Forms.Button();
//            this.lblHelloWorld = new System.Windows.Forms.Label();
//            this.pictureBox_show = new System.Windows.Forms.PictureBox();
//            this.button_open = new System.Windows.Forms.Button();
//            this.button3 = new System.Windows.Forms.Button();
//            this.button4 = new System.Windows.Forms.Button();
//            this.button5 = new System.Windows.Forms.Button();
//            this.button6 = new System.Windows.Forms.Button();
//            this.button7 = new System.Windows.Forms.Button();
//            this.退出 = new System.Windows.Forms.Button();
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_show)).BeginInit();
//            this.SuspendLayout();
//            // 
//            // button1
//            // 
//            this.button1.Location = new System.Drawing.Point(571, 37);
//            this.button1.Name = "button1";
//            this.button1.Size = new System.Drawing.Size(127, 23);
//            this.button1.TabIndex = 0;
//            this.button1.Text = "btnClickThis";
//            this.button1.UseVisualStyleBackColor = true;
//            this.button1.Click += new System.EventHandler(this.button1_Click);
//            // 
//            // lblHelloWorld
//            // 
//            this.lblHelloWorld.AutoSize = true;
//            this.lblHelloWorld.Location = new System.Drawing.Point(634, 132);
//            this.lblHelloWorld.Name = "lblHelloWorld";
//            this.lblHelloWorld.Size = new System.Drawing.Size(111, 15);
//            this.lblHelloWorld.TabIndex = 1;
//            this.lblHelloWorld.Text = "lblHelloWorld";
//            // 
//            // pictureBox_show
//            // 
//            this.pictureBox_show.BackColor = System.Drawing.SystemColors.AppWorkspace;
//            this.pictureBox_show.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
//            this.pictureBox_show.Location = new System.Drawing.Point(54, 75);
//            this.pictureBox_show.Name = "pictureBox_show";
//            this.pictureBox_show.Size = new System.Drawing.Size(378, 320);
//            this.pictureBox_show.TabIndex = 2;
//            this.pictureBox_show.TabStop = false;
//            // 
//            // button_open
//            // 
//            this.button_open.BackColor = System.Drawing.SystemColors.MenuHighlight;
//            this.button_open.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
//            this.button_open.Font = new System.Drawing.Font("宋体", 12F);
//            this.button_open.ForeColor = System.Drawing.SystemColors.ButtonFace;
//            this.button_open.Location = new System.Drawing.Point(527, 146);
//            this.button_open.Name = "button_open";
//            this.button_open.Size = new System.Drawing.Size(72, 39);
//            this.button_open.TabIndex = 3;
//            this.button_open.Text = "打开";
//            this.button_open.UseVisualStyleBackColor = false;
//            // 
//            // button3
//            // 
//            this.button3.Location = new System.Drawing.Point(375, 232);
//            this.button3.Name = "button3";
//            this.button3.Size = new System.Drawing.Size(75, 23);
//            this.button3.TabIndex = 4;
//            this.button3.Text = "button3";
//            this.button3.UseVisualStyleBackColor = true;
//            // 
//            // button4
//            // 
//            this.button4.Location = new System.Drawing.Point(571, 237);
//            this.button4.Name = "button4";
//            this.button4.Size = new System.Drawing.Size(75, 23);
//            this.button4.TabIndex = 5;
//            this.button4.Text = "button4";
//            this.button4.UseVisualStyleBackColor = true;
//            // 
//            // button5
//            // 
//            this.button5.Location = new System.Drawing.Point(391, 248);
//            this.button5.Name = "button5";
//            this.button5.Size = new System.Drawing.Size(75, 23);
//            this.button5.TabIndex = 6;
//            this.button5.Text = "button5";
//            this.button5.UseVisualStyleBackColor = true;
//            // 
//            // button6
//            // 
//            this.button6.Location = new System.Drawing.Point(399, 256);
//            this.button6.Name = "button6";
//            this.button6.Size = new System.Drawing.Size(75, 23);
//            this.button6.TabIndex = 7;
//            this.button6.Text = "button6";
//            this.button6.UseVisualStyleBackColor = true;
//            // 
//            // button7
//            // 
//            this.button7.Location = new System.Drawing.Point(571, 266);
//            this.button7.Name = "button7";
//            this.button7.Size = new System.Drawing.Size(75, 23);
//            this.button7.TabIndex = 8;
//            this.button7.Text = "button7";
//            this.button7.UseVisualStyleBackColor = true;
//            // 
//            // 退出
//            // 
//            this.退出.Location = new System.Drawing.Point(623, 96);
//            this.退出.Name = "退出";
//            this.退出.Size = new System.Drawing.Size(75, 23);
//            this.退出.TabIndex = 9;
//            this.退出.Text = "button_exit";
//            this.退出.UseVisualStyleBackColor = true;
//            // 
//            // Form1
//            // 
//            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
//            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
//            this.ClientSize = new System.Drawing.Size(1071, 642);
//            this.Controls.Add(this.退出);
//            this.Controls.Add(this.button7);
//            this.Controls.Add(this.button6);
//            this.Controls.Add(this.button5);
//            this.Controls.Add(this.button4);
//            this.Controls.Add(this.button3);
//            this.Controls.Add(this.button_open);
//            this.Controls.Add(this.pictureBox_show);
//            this.Controls.Add(this.lblHelloWorld);
//            this.Controls.Add(this.button1);
//            this.Name = "Form1";
//            this.Text = "Form1";
//            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_show)).EndInit();
//            this.ResumeLayout(false);
//            this.PerformLayout();

//        }

//        #endregion

//        private System.Windows.Forms.Button button1;
//        private System.Windows.Forms.Label lblHelloWorld;
//        private System.Windows.Forms.PictureBox pictureBox_show;
//        private System.Windows.Forms.Button button3;
//        private System.Windows.Forms.Button button4;
//        private System.Windows.Forms.Button button5;
//        private System.Windows.Forms.Button button6;
//        private System.Windows.Forms.Button button7;
//        private System.Windows.Forms.Button button_open;
//        private System.Windows.Forms.Button 退出;
//    }



//    public class myButton : System.Windows.Forms.Button
//    {
//        private Color enterForeColor = Color.White;
//        private Color leftForeColor = Color.Black;
//        private bool Isleft = true;

//        public bool IsLEFT
//        {
//            get { return Isleft; }
//            set
//            {
//                this.Isleft = value;
//            }
//        }

//        public Color EnterForeColor
//        {
//            get { return enterForeColor; }
//            set
//            {
//                this.enterForeColor = value;
//                this.ForeColor = value;
//            }
//        }
//        public Color LeftForeColor
//        {
//            get { return leftForeColor; }
//            set
//            {
//                this.leftForeColor = value;
//                this.ForeColor = value;
//            }
//        }
//        [DefaultValue(typeof(Color), "51, 161, 224")]
//        //  [DefaultValue(typeof(Color), "220, 80, 80")]


//        //  [DefaultValue(typeof(Color), "251, 161, 0")]
//        protected override void OnMouseEnter(EventArgs e)//鼠标进入时
//        {
//            base.OnMouseEnter(e);
//            this.ForeColor = this.EnterForeColor;
//        }
//        protected override void OnMouseLeave(EventArgs e)//鼠标离开
//        {
//            base.OnMouseLeave(e);
//            this.ForeColor = this.LeftForeColor;
//        }

//        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
//        {
//            base.OnPaint(e);
//            base.OnPaintBackground(e);
//            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
//            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
//            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
//            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
//            Rectangle rect = new Rectangle(0, 0, this.Width, this.Height);
//            var path = GetRoundedRectPath(rect);
//            this.Region = new Region(path);

//            //var pa = RectPath(rect);
//            //this.Region = new Region(pa);
//            Color baseColor = this.BackColor;

//            using (SolidBrush b = new SolidBrush(baseColor))
//            {
//                e.Graphics.FillPath(b, path);
//                //e.Graphics.FillPath(b, pa);
//                System.Drawing.Font fo = new System.Drawing.Font(this.Font.Name, this.Font.Size);
//                Brush brush = new SolidBrush(this.ForeColor);
//                Pen penn = new Pen(brush, 3);
//                StringFormat gs = new StringFormat();
//                gs.Alignment = StringAlignment.Center; //居中
//                gs.LineAlignment = StringAlignment.Center;//垂直居中
//                e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
//                e.Graphics.DrawString(this.Text, fo, brush, rect, gs);
//            }

//        }
//        private GraphicsPath RectPath(Rectangle re)
//        {
//            GraphicsPath path = new GraphicsPath();
//            Point[] ps = new Point[4];
//            ps[0] = new Point(this.Width / 5, this.Height / 5);
//            ps[1] = new Point(4 * this.Width / 5, this.Height / 5);
//            ps[2] = new Point(this.Width / 5, 4 * this.Height / 5);
//            ps[3] = new Point(4 * this.Width / 5, 4 * this.Height / 5);
//            path.AddLines(ps);
//            path.CloseFigure();

//            return path;
//        }
//        private GraphicsPath GetRoundedRectPath(Rectangle rect)
//        {
//            Rectangle arcRect = new Rectangle(rect.Location, new System.Drawing.Size(this.Height, this.Height));
//            GraphicsPath path = new GraphicsPath();
//            Point[] p = new Point[12];
//            if (Isleft == true)
//            {
//                p[0] = new Point(2 * this.Width / 5, 0);
//                p[1] = new Point(0, this.Height / 2);
//                p[2] = new Point(2 * this.Width / 5, this.Height);

//                p[3] = new Point(this.Width, 0);
//                p[4] = new Point(4 * this.Width / 5, this.Height / 4);
//                p[5] = new Point(4 * this.Width / 5, 3 * this.Height / 4);
//                p[6] = new Point(this.Width, this.Height);
//            }
//            else
//            {
//                p[0] = new Point(3 * this.Width / 5, 0);
//                p[1] = new Point(this.Width, this.Height / 2);
//                p[2] = new Point(3 * this.Width / 5, this.Height);

//                p[3] = new Point(0, 0);
//                p[5] = new Point(1 * this.Width / 5, 3 * this.Height / 4);
//                p[6] = new Point(0, this.Height);
//            }
//            path.AddLine(p[0], p[1]);
//            path.AddLine(p[1], p[2]);
//            path.AddBezier(p[6], p[5], p[4], p[3]);
//            path.CloseFigure();
//            return path;
//        }
//    }

//}


using System.ComponentModel;
using System.Drawing.Drawing2D;
using System.Drawing;
using System;

namespace imageIdentification
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_open = new System.Windows.Forms.Button();
            this.pictureBox_show = new System.Windows.Forms.PictureBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btn_gray = new System.Windows.Forms.Button();
            this.btn_restore = new System.Windows.Forms.Button();
            this.btn_hsi = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.trackBar_binary = new System.Windows.Forms.TrackBar();
            this.textBox_showBinary = new System.Windows.Forms.TextBox();
            this.btnBinaryadjust = new System.Windows.Forms.Button();
            this.comboBox_colorCollect = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnColoradjust = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_smoothCollect = new System.Windows.Forms.ComboBox();
            this.btnSmoothadjust = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_sharpeningCollect = new System.Windows.Forms.ComboBox();
            this.btnSharpeningadjust = new System.Windows.Forms.Button();
            this.comboBox_binaryChangeCollect = new System.Windows.Forms.ComboBox();
            this.btnBinaryChangeadjust = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnGaussianadjust = new System.Windows.Forms.Button();
            this.textBox_showImpulseNoise = new System.Windows.Forms.TextBox();
            this.trackBar_impulseNoise = new System.Windows.Forms.TrackBar();
            this.btnImpulseadjust = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_gaussianAvg = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_gaussianVariance = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.trackBar_RandomNoise = new System.Windows.Forms.TrackBar();
            this.textBox_showRandomNoise = new System.Windows.Forms.TextBox();
            this.btnRandomadjust = new System.Windows.Forms.Button();
            this.btn_magnify = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox_structureElementValue = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox_structureElementSelect = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox_picCategory = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.trackBar_brightness = new System.Windows.Forms.TrackBar();
            this.btnBrightnessadjust = new System.Windows.Forms.Button();
            this.textBox_showBrightness = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBar_contrast = new System.Windows.Forms.TrackBar();
            this.textBox_showContrast = new System.Windows.Forms.TextBox();
            this.btnContrastAdjust = new System.Windows.Forms.Button();
            this.btnSpinadjust = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.trackBar_spin = new System.Windows.Forms.TrackBar();
            this.textBox_showSpin = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.btn_edgeFillOrigin = new System.Windows.Forms.Button();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox_WeiCaiSeCollect = new System.Windows.Forms.ComboBox();
            this.btnWeiCaiSe = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.trackBar_grayLevel = new System.Windows.Forms.TrackBar();
            this.textBox_showGrayLevel = new System.Windows.Forms.TextBox();
            this.btn_GrayLevel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_binary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_impulseNoise)).BeginInit();
            this.flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_RandomNoise)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_brightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_contrast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_spin)).BeginInit();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_grayLevel)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_open
            // 
            this.btn_open.BackColor = System.Drawing.Color.Transparent;
            this.btn_open.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_open.BackgroundImage")));
            this.btn_open.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_open.FlatAppearance.BorderSize = 0;
            this.btn_open.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_open.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_open.Location = new System.Drawing.Point(617, 35);
            this.btn_open.Name = "btn_open";
            this.btn_open.Size = new System.Drawing.Size(91, 57);
            this.btn_open.TabIndex = 0;
            this.btn_open.UseVisualStyleBackColor = false;
            this.btn_open.Click += new System.EventHandler(this.btn_open_Click);
            // 
            // pictureBox_show
            // 
            this.pictureBox_show.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox_show.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox_show.Location = new System.Drawing.Point(23, 24);
            this.pictureBox_show.Name = "pictureBox_show";
            this.pictureBox_show.Size = new System.Drawing.Size(503, 456);
            this.pictureBox_show.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox_show.TabIndex = 2;
            this.pictureBox_show.TabStop = false;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Transparent;
            this.btn_save.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_save.BackgroundImage")));
            this.btn_save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_save.FlatAppearance.BorderSize = 0;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Location = new System.Drawing.Point(825, 35);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(101, 57);
            this.btn_save.TabIndex = 3;
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_gray
            // 
            this.btn_gray.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_gray.BackgroundImage")));
            this.btn_gray.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_gray.FlatAppearance.BorderSize = 0;
            this.btn_gray.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_gray.Location = new System.Drawing.Point(1228, 128);
            this.btn_gray.Name = "btn_gray";
            this.btn_gray.Size = new System.Drawing.Size(101, 41);
            this.btn_gray.TabIndex = 4;
            this.btn_gray.UseVisualStyleBackColor = true;
            this.btn_gray.Click += new System.EventHandler(this.btn_gray_Click);
            // 
            // btn_restore
            // 
            this.btn_restore.BackColor = System.Drawing.Color.Transparent;
            this.btn_restore.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_restore.BackgroundImage")));
            this.btn_restore.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_restore.FlatAppearance.BorderSize = 0;
            this.btn_restore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_restore.Location = new System.Drawing.Point(725, 35);
            this.btn_restore.Name = "btn_restore";
            this.btn_restore.Size = new System.Drawing.Size(92, 57);
            this.btn_restore.TabIndex = 5;
            this.btn_restore.UseVisualStyleBackColor = false;
            this.btn_restore.Click += new System.EventHandler(this.btn_restore_Click);
            // 
            // btn_hsi
            // 
            this.btn_hsi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_hsi.BackgroundImage")));
            this.btn_hsi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_hsi.FlatAppearance.BorderSize = 0;
            this.btn_hsi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hsi.Location = new System.Drawing.Point(1121, 128);
            this.btn_hsi.Name = "btn_hsi";
            this.btn_hsi.Size = new System.Drawing.Size(101, 41);
            this.btn_hsi.TabIndex = 15;
            this.btn_hsi.UseVisualStyleBackColor = true;
            this.btn_hsi.Click += new System.EventHandler(this.btn_hsi_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F);
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "二值化阈值";
            // 
            // trackBar_binary
            // 
            this.trackBar_binary.Location = new System.Drawing.Point(118, 3);
            this.trackBar_binary.Maximum = 255;
            this.trackBar_binary.Name = "trackBar_binary";
            this.trackBar_binary.Size = new System.Drawing.Size(158, 56);
            this.trackBar_binary.TabIndex = 17;
            this.trackBar_binary.TabStop = false;
            this.trackBar_binary.Scroll += new System.EventHandler(this.trackBar_binary_Scroll);
            // 
            // textBox_showBinary
            // 
            this.textBox_showBinary.Location = new System.Drawing.Point(282, 3);
            this.textBox_showBinary.Name = "textBox_showBinary";
            this.textBox_showBinary.Size = new System.Drawing.Size(50, 25);
            this.textBox_showBinary.TabIndex = 18;
            // 
            // btnBinaryadjust
            // 
            this.btnBinaryadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBinaryadjust.BackgroundImage")));
            this.btnBinaryadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBinaryadjust.FlatAppearance.BorderSize = 0;
            this.btnBinaryadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBinaryadjust.Location = new System.Drawing.Point(338, 3);
            this.btnBinaryadjust.Name = "btnBinaryadjust";
            this.btnBinaryadjust.Size = new System.Drawing.Size(101, 41);
            this.btnBinaryadjust.TabIndex = 19;
            this.btnBinaryadjust.UseVisualStyleBackColor = true;
            this.btnBinaryadjust.Click += new System.EventHandler(this.btnBinaryadjust_Click);
            // 
            // comboBox_colorCollect
            // 
            this.comboBox_colorCollect.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_colorCollect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_colorCollect.FormattingEnabled = true;
            this.comboBox_colorCollect.Location = new System.Drawing.Point(138, 754);
            this.comboBox_colorCollect.Name = "comboBox_colorCollect";
            this.comboBox_colorCollect.Size = new System.Drawing.Size(140, 23);
            this.comboBox_colorCollect.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F);
            this.label4.Location = new System.Drawing.Point(21, 757);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 22;
            this.label4.Text = "通道提取";
            // 
            // btnColoradjust
            // 
            this.btnColoradjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnColoradjust.BackgroundImage")));
            this.btnColoradjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnColoradjust.FlatAppearance.BorderSize = 0;
            this.btnColoradjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColoradjust.Location = new System.Drawing.Point(316, 744);
            this.btnColoradjust.Name = "btnColoradjust";
            this.btnColoradjust.Size = new System.Drawing.Size(101, 41);
            this.btnColoradjust.TabIndex = 23;
            this.btnColoradjust.UseVisualStyleBackColor = true;
            this.btnColoradjust.Click += new System.EventHandler(this.btn_colorCollect_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F);
            this.label5.Location = new System.Drawing.Point(3, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "图像平滑";
            // 
            // comboBox_smoothCollect
            // 
            this.comboBox_smoothCollect.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_smoothCollect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_smoothCollect.Font = new System.Drawing.Font("宋体", 12F);
            this.comboBox_smoothCollect.FormattingEnabled = true;
            this.comboBox_smoothCollect.Location = new System.Drawing.Point(98, 174);
            this.comboBox_smoothCollect.Name = "comboBox_smoothCollect";
            this.comboBox_smoothCollect.Size = new System.Drawing.Size(158, 28);
            this.comboBox_smoothCollect.TabIndex = 25;
            // 
            // btnSmoothadjust
            // 
            this.btnSmoothadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSmoothadjust.BackgroundImage")));
            this.btnSmoothadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSmoothadjust.FlatAppearance.BorderSize = 0;
            this.btnSmoothadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSmoothadjust.Location = new System.Drawing.Point(262, 174);
            this.btnSmoothadjust.Name = "btnSmoothadjust";
            this.btnSmoothadjust.Size = new System.Drawing.Size(89, 41);
            this.btnSmoothadjust.TabIndex = 26;
            this.btnSmoothadjust.UseVisualStyleBackColor = true;
            this.btnSmoothadjust.Click += new System.EventHandler(this.btnSmoothadjust_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F);
            this.label6.Location = new System.Drawing.Point(3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 20);
            this.label6.TabIndex = 27;
            this.label6.Text = "图像边缘提取";
            // 
            // comboBox_sharpeningCollect
            // 
            this.comboBox_sharpeningCollect.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_sharpeningCollect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_sharpeningCollect.Font = new System.Drawing.Font("宋体", 12F);
            this.comboBox_sharpeningCollect.FormattingEnabled = true;
            this.comboBox_sharpeningCollect.Location = new System.Drawing.Point(138, 3);
            this.comboBox_sharpeningCollect.Name = "comboBox_sharpeningCollect";
            this.comboBox_sharpeningCollect.Size = new System.Drawing.Size(194, 28);
            this.comboBox_sharpeningCollect.TabIndex = 28;
            // 
            // btnSharpeningadjust
            // 
            this.btnSharpeningadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSharpeningadjust.BackgroundImage")));
            this.btnSharpeningadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSharpeningadjust.FlatAppearance.BorderSize = 0;
            this.btnSharpeningadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSharpeningadjust.Location = new System.Drawing.Point(338, 3);
            this.btnSharpeningadjust.Name = "btnSharpeningadjust";
            this.btnSharpeningadjust.Size = new System.Drawing.Size(101, 41);
            this.btnSharpeningadjust.TabIndex = 29;
            this.btnSharpeningadjust.UseVisualStyleBackColor = true;
            this.btnSharpeningadjust.Click += new System.EventHandler(this.btnSharpeningadjust_Click);
            // 
            // comboBox_binaryChangeCollect
            // 
            this.comboBox_binaryChangeCollect.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_binaryChangeCollect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_binaryChangeCollect.FormattingEnabled = true;
            this.comboBox_binaryChangeCollect.Location = new System.Drawing.Point(118, 65);
            this.comboBox_binaryChangeCollect.Name = "comboBox_binaryChangeCollect";
            this.comboBox_binaryChangeCollect.Size = new System.Drawing.Size(202, 23);
            this.comboBox_binaryChangeCollect.TabIndex = 30;
            // 
            // btnBinaryChangeadjust
            // 
            this.btnBinaryChangeadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBinaryChangeadjust.BackgroundImage")));
            this.btnBinaryChangeadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBinaryChangeadjust.FlatAppearance.BorderSize = 0;
            this.btnBinaryChangeadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBinaryChangeadjust.Location = new System.Drawing.Point(326, 65);
            this.btnBinaryChangeadjust.Name = "btnBinaryChangeadjust";
            this.btnBinaryChangeadjust.Size = new System.Drawing.Size(87, 44);
            this.btnBinaryChangeadjust.TabIndex = 31;
            this.btnBinaryChangeadjust.UseVisualStyleBackColor = true;
            this.btnBinaryChangeadjust.Click += new System.EventHandler(this.btnBinaryChangeadjust_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("宋体", 12F);
            this.label7.Location = new System.Drawing.Point(3, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "形态学变换";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("宋体", 12F);
            this.label8.Location = new System.Drawing.Point(3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "高斯噪声";
            // 
            // btnGaussianadjust
            // 
            this.btnGaussianadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGaussianadjust.BackgroundImage")));
            this.btnGaussianadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGaussianadjust.FlatAppearance.BorderSize = 0;
            this.btnGaussianadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGaussianadjust.Location = new System.Drawing.Point(326, 3);
            this.btnGaussianadjust.Name = "btnGaussianadjust";
            this.btnGaussianadjust.Size = new System.Drawing.Size(101, 41);
            this.btnGaussianadjust.TabIndex = 35;
            this.btnGaussianadjust.UseVisualStyleBackColor = true;
            this.btnGaussianadjust.Click += new System.EventHandler(this.btnGaussianadjust_Click);
            // 
            // textBox_showImpulseNoise
            // 
            this.textBox_showImpulseNoise.Location = new System.Drawing.Point(270, 50);
            this.textBox_showImpulseNoise.Name = "textBox_showImpulseNoise";
            this.textBox_showImpulseNoise.Size = new System.Drawing.Size(50, 25);
            this.textBox_showImpulseNoise.TabIndex = 41;
            // 
            // trackBar_impulseNoise
            // 
            this.trackBar_impulseNoise.Location = new System.Drawing.Point(98, 50);
            this.trackBar_impulseNoise.Maximum = 100;
            this.trackBar_impulseNoise.Minimum = 1;
            this.trackBar_impulseNoise.Name = "trackBar_impulseNoise";
            this.trackBar_impulseNoise.Size = new System.Drawing.Size(166, 56);
            this.trackBar_impulseNoise.TabIndex = 40;
            this.trackBar_impulseNoise.TabStop = false;
            this.trackBar_impulseNoise.Value = 1;
            this.trackBar_impulseNoise.Scroll += new System.EventHandler(this.trackBar_impulseNoise_Scroll);
            // 
            // btnImpulseadjust
            // 
            this.btnImpulseadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnImpulseadjust.BackgroundImage")));
            this.btnImpulseadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnImpulseadjust.FlatAppearance.BorderSize = 0;
            this.btnImpulseadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImpulseadjust.Location = new System.Drawing.Point(326, 50);
            this.btnImpulseadjust.Name = "btnImpulseadjust";
            this.btnImpulseadjust.Size = new System.Drawing.Size(101, 41);
            this.btnImpulseadjust.TabIndex = 39;
            this.btnImpulseadjust.UseVisualStyleBackColor = true;
            this.btnImpulseadjust.Click += new System.EventHandler(this.btnImpulseadjust_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("宋体", 12F);
            this.label9.Location = new System.Drawing.Point(3, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 20);
            this.label9.TabIndex = 38;
            this.label9.Text = "椒盐噪声";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.flowLayoutPanel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel2.Controls.Add(this.label8);
            this.flowLayoutPanel2.Controls.Add(this.label12);
            this.flowLayoutPanel2.Controls.Add(this.textBox_gaussianAvg);
            this.flowLayoutPanel2.Controls.Add(this.label13);
            this.flowLayoutPanel2.Controls.Add(this.textBox_gaussianVariance);
            this.flowLayoutPanel2.Controls.Add(this.btnGaussianadjust);
            this.flowLayoutPanel2.Controls.Add(this.label9);
            this.flowLayoutPanel2.Controls.Add(this.trackBar_impulseNoise);
            this.flowLayoutPanel2.Controls.Add(this.textBox_showImpulseNoise);
            this.flowLayoutPanel2.Controls.Add(this.btnImpulseadjust);
            this.flowLayoutPanel2.Controls.Add(this.label11);
            this.flowLayoutPanel2.Controls.Add(this.trackBar_RandomNoise);
            this.flowLayoutPanel2.Controls.Add(this.textBox_showRandomNoise);
            this.flowLayoutPanel2.Controls.Add(this.btnRandomadjust);
            this.flowLayoutPanel2.Controls.Add(this.label5);
            this.flowLayoutPanel2.Controls.Add(this.comboBox_smoothCollect);
            this.flowLayoutPanel2.Controls.Add(this.btnSmoothadjust);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(593, 128);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(490, 234);
            this.flowLayoutPanel2.TabIndex = 43;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 12F);
            this.label12.Location = new System.Drawing.Point(98, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 20);
            this.label12.TabIndex = 52;
            this.label12.Text = "均值";
            // 
            // textBox_gaussianAvg
            // 
            this.textBox_gaussianAvg.Location = new System.Drawing.Point(153, 3);
            this.textBox_gaussianAvg.Name = "textBox_gaussianAvg";
            this.textBox_gaussianAvg.Size = new System.Drawing.Size(43, 25);
            this.textBox_gaussianAvg.TabIndex = 46;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 12F);
            this.label13.Location = new System.Drawing.Point(202, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 20);
            this.label13.TabIndex = 54;
            this.label13.Text = "标准差";
            // 
            // textBox_gaussianVariance
            // 
            this.textBox_gaussianVariance.Location = new System.Drawing.Point(277, 3);
            this.textBox_gaussianVariance.Name = "textBox_gaussianVariance";
            this.textBox_gaussianVariance.Size = new System.Drawing.Size(43, 25);
            this.textBox_gaussianVariance.TabIndex = 53;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F);
            this.label11.Location = new System.Drawing.Point(3, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 20);
            this.label11.TabIndex = 42;
            this.label11.Text = "随机噪声";
            // 
            // trackBar_RandomNoise
            // 
            this.trackBar_RandomNoise.Location = new System.Drawing.Point(98, 112);
            this.trackBar_RandomNoise.Maximum = 255;
            this.trackBar_RandomNoise.Minimum = 1;
            this.trackBar_RandomNoise.Name = "trackBar_RandomNoise";
            this.trackBar_RandomNoise.Size = new System.Drawing.Size(166, 56);
            this.trackBar_RandomNoise.TabIndex = 43;
            this.trackBar_RandomNoise.TabStop = false;
            this.trackBar_RandomNoise.Value = 1;
            this.trackBar_RandomNoise.Scroll += new System.EventHandler(this.trackBar_RandomNoise_Scroll);
            // 
            // textBox_showRandomNoise
            // 
            this.textBox_showRandomNoise.Location = new System.Drawing.Point(270, 112);
            this.textBox_showRandomNoise.Name = "textBox_showRandomNoise";
            this.textBox_showRandomNoise.Size = new System.Drawing.Size(50, 25);
            this.textBox_showRandomNoise.TabIndex = 44;
            // 
            // btnRandomadjust
            // 
            this.btnRandomadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRandomadjust.BackgroundImage")));
            this.btnRandomadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRandomadjust.FlatAppearance.BorderSize = 0;
            this.btnRandomadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRandomadjust.Location = new System.Drawing.Point(326, 112);
            this.btnRandomadjust.Name = "btnRandomadjust";
            this.btnRandomadjust.Size = new System.Drawing.Size(101, 41);
            this.btnRandomadjust.TabIndex = 45;
            this.btnRandomadjust.UseVisualStyleBackColor = true;
            this.btnRandomadjust.Click += new System.EventHandler(this.btnRandomadjust_Click);
            // 
            // btn_magnify
            // 
            this.btn_magnify.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_magnify.BackgroundImage")));
            this.btn_magnify.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_magnify.FlatAppearance.BorderSize = 0;
            this.btn_magnify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_magnify.Location = new System.Drawing.Point(1121, 186);
            this.btn_magnify.Name = "btn_magnify";
            this.btn_magnify.Size = new System.Drawing.Size(107, 48);
            this.btn_magnify.TabIndex = 44;
            this.btn_magnify.UseVisualStyleBackColor = true;
            this.btn_magnify.Click += new System.EventHandler(this.btn_magnify_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.trackBar_binary);
            this.flowLayoutPanel1.Controls.Add(this.textBox_showBinary);
            this.flowLayoutPanel1.Controls.Add(this.btnBinaryadjust);
            this.flowLayoutPanel1.Controls.Add(this.label7);
            this.flowLayoutPanel1.Controls.Add(this.comboBox_binaryChangeCollect);
            this.flowLayoutPanel1.Controls.Add(this.btnBinaryChangeadjust);
            this.flowLayoutPanel1.Controls.Add(this.label14);
            this.flowLayoutPanel1.Controls.Add(this.textBox_structureElementValue);
            this.flowLayoutPanel1.Controls.Add(this.label15);
            this.flowLayoutPanel1.Controls.Add(this.comboBox_structureElementSelect);
            this.flowLayoutPanel1.Controls.Add(this.label16);
            this.flowLayoutPanel1.Controls.Add(this.comboBox_picCategory);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(593, 391);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(490, 148);
            this.flowLayoutPanel1.TabIndex = 51;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 12F);
            this.label14.Location = new System.Drawing.Point(3, 112);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 20);
            this.label14.TabIndex = 53;
            this.label14.Text = "SE大小";
            // 
            // textBox_structureElementValue
            // 
            this.textBox_structureElementValue.Font = new System.Drawing.Font("宋体", 12F);
            this.textBox_structureElementValue.Location = new System.Drawing.Point(78, 115);
            this.textBox_structureElementValue.Name = "textBox_structureElementValue";
            this.textBox_structureElementValue.Size = new System.Drawing.Size(50, 30);
            this.textBox_structureElementValue.TabIndex = 54;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 12F);
            this.label15.Location = new System.Drawing.Point(134, 112);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 20);
            this.label15.TabIndex = 55;
            this.label15.Text = "SE模板";
            // 
            // comboBox_structureElementSelect
            // 
            this.comboBox_structureElementSelect.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_structureElementSelect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_structureElementSelect.Font = new System.Drawing.Font("宋体", 12F);
            this.comboBox_structureElementSelect.FormattingEnabled = true;
            this.comboBox_structureElementSelect.Location = new System.Drawing.Point(209, 115);
            this.comboBox_structureElementSelect.Name = "comboBox_structureElementSelect";
            this.comboBox_structureElementSelect.Size = new System.Drawing.Size(111, 28);
            this.comboBox_structureElementSelect.TabIndex = 55;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 12F);
            this.label16.Location = new System.Drawing.Point(326, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 20);
            this.label16.TabIndex = 56;
            this.label16.Text = "类型";
            // 
            // comboBox_picCategory
            // 
            this.comboBox_picCategory.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_picCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_picCategory.Font = new System.Drawing.Font("宋体", 12F);
            this.comboBox_picCategory.FormattingEnabled = true;
            this.comboBox_picCategory.Location = new System.Drawing.Point(381, 115);
            this.comboBox_picCategory.Name = "comboBox_picCategory";
            this.comboBox_picCategory.Size = new System.Drawing.Size(90, 28);
            this.comboBox_picCategory.TabIndex = 57;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(30, 557);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "亮度调节";
            // 
            // trackBar_brightness
            // 
            this.trackBar_brightness.Location = new System.Drawing.Point(137, 541);
            this.trackBar_brightness.Maximum = 255;
            this.trackBar_brightness.Minimum = -255;
            this.trackBar_brightness.Name = "trackBar_brightness";
            this.trackBar_brightness.Size = new System.Drawing.Size(213, 56);
            this.trackBar_brightness.TabIndex = 7;
            this.trackBar_brightness.TabStop = false;
            this.trackBar_brightness.Scroll += new System.EventHandler(this.trackBar_brightness_Scroll);
            // 
            // btnBrightnessadjust
            // 
            this.btnBrightnessadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrightnessadjust.BackgroundImage")));
            this.btnBrightnessadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBrightnessadjust.FlatAppearance.BorderSize = 0;
            this.btnBrightnessadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrightnessadjust.Location = new System.Drawing.Point(425, 548);
            this.btnBrightnessadjust.Name = "btnBrightnessadjust";
            this.btnBrightnessadjust.Size = new System.Drawing.Size(101, 41);
            this.btnBrightnessadjust.TabIndex = 8;
            this.btnBrightnessadjust.UseVisualStyleBackColor = true;
            this.btnBrightnessadjust.Click += new System.EventHandler(this.btnBrightnessadjust_Click);
            // 
            // textBox_showBrightness
            // 
            this.textBox_showBrightness.Location = new System.Drawing.Point(356, 552);
            this.textBox_showBrightness.Name = "textBox_showBrightness";
            this.textBox_showBrightness.Size = new System.Drawing.Size(50, 25);
            this.textBox_showBrightness.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F);
            this.label2.Location = new System.Drawing.Point(22, 627);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "对比度调节";
            // 
            // trackBar_contrast
            // 
            this.trackBar_contrast.Location = new System.Drawing.Point(137, 618);
            this.trackBar_contrast.Maximum = 255;
            this.trackBar_contrast.Minimum = -255;
            this.trackBar_contrast.Name = "trackBar_contrast";
            this.trackBar_contrast.Size = new System.Drawing.Size(213, 56);
            this.trackBar_contrast.TabIndex = 12;
            this.trackBar_contrast.TabStop = false;
            this.trackBar_contrast.Scroll += new System.EventHandler(this.trackBar_contrast_Scroll);
            // 
            // textBox_showContrast
            // 
            this.textBox_showContrast.Location = new System.Drawing.Point(356, 628);
            this.textBox_showContrast.Name = "textBox_showContrast";
            this.textBox_showContrast.Size = new System.Drawing.Size(50, 25);
            this.textBox_showContrast.TabIndex = 13;
            // 
            // btnContrastAdjust
            // 
            this.btnContrastAdjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnContrastAdjust.BackgroundImage")));
            this.btnContrastAdjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnContrastAdjust.FlatAppearance.BorderSize = 0;
            this.btnContrastAdjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContrastAdjust.Location = new System.Drawing.Point(425, 618);
            this.btnContrastAdjust.Name = "btnContrastAdjust";
            this.btnContrastAdjust.Size = new System.Drawing.Size(101, 41);
            this.btnContrastAdjust.TabIndex = 14;
            this.btnContrastAdjust.UseVisualStyleBackColor = true;
            this.btnContrastAdjust.Click += new System.EventHandler(this.btnContrastAdjust_Click);
            // 
            // btnSpinadjust
            // 
            this.btnSpinadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSpinadjust.BackgroundImage")));
            this.btnSpinadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSpinadjust.FlatAppearance.BorderSize = 0;
            this.btnSpinadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSpinadjust.Location = new System.Drawing.Point(425, 682);
            this.btnSpinadjust.Name = "btnSpinadjust";
            this.btnSpinadjust.Size = new System.Drawing.Size(101, 41);
            this.btnSpinadjust.TabIndex = 50;
            this.btnSpinadjust.UseVisualStyleBackColor = true;
            this.btnSpinadjust.Click += new System.EventHandler(this.btnSpinadjust_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F);
            this.label10.Location = new System.Drawing.Point(22, 691);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 20);
            this.label10.TabIndex = 47;
            this.label10.Text = "图像旋转";
            // 
            // trackBar_spin
            // 
            this.trackBar_spin.Location = new System.Drawing.Point(130, 691);
            this.trackBar_spin.Maximum = 180;
            this.trackBar_spin.Minimum = -180;
            this.trackBar_spin.Name = "trackBar_spin";
            this.trackBar_spin.Size = new System.Drawing.Size(213, 56);
            this.trackBar_spin.TabIndex = 48;
            this.trackBar_spin.TabStop = false;
            this.trackBar_spin.Scroll += new System.EventHandler(this.trackBar_spin_Scroll);
            // 
            // textBox_showSpin
            // 
            this.textBox_showSpin.Location = new System.Drawing.Point(356, 692);
            this.textBox_showSpin.Name = "textBox_showSpin";
            this.textBox_showSpin.Size = new System.Drawing.Size(50, 25);
            this.textBox_showSpin.TabIndex = 49;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.flowLayoutPanel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel3.Controls.Add(this.label6);
            this.flowLayoutPanel3.Controls.Add(this.comboBox_sharpeningCollect);
            this.flowLayoutPanel3.Controls.Add(this.btnSharpeningadjust);
            this.flowLayoutPanel3.Controls.Add(this.label17);
            this.flowLayoutPanel3.Controls.Add(this.btn_edgeFillOrigin);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(593, 579);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(497, 104);
            this.flowLayoutPanel3.TabIndex = 55;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("宋体", 12F);
            this.label17.Location = new System.Drawing.Point(3, 47);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(209, 20);
            this.label17.TabIndex = 59;
            this.label17.Text = "边缘叠加原图（锐化）";
            // 
            // btn_edgeFillOrigin
            // 
            this.btn_edgeFillOrigin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_edgeFillOrigin.BackgroundImage")));
            this.btn_edgeFillOrigin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_edgeFillOrigin.FlatAppearance.BorderSize = 0;
            this.btn_edgeFillOrigin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_edgeFillOrigin.Location = new System.Drawing.Point(218, 50);
            this.btn_edgeFillOrigin.Name = "btn_edgeFillOrigin";
            this.btn_edgeFillOrigin.Size = new System.Drawing.Size(87, 44);
            this.btn_edgeFillOrigin.TabIndex = 58;
            this.btn_edgeFillOrigin.UseVisualStyleBackColor = true;
            this.btn_edgeFillOrigin.Click += new System.EventHandler(this.btn_edgeFillOrigin_Click);
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.flowLayoutPanel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel4.Controls.Add(this.label18);
            this.flowLayoutPanel4.Controls.Add(this.comboBox_WeiCaiSeCollect);
            this.flowLayoutPanel4.Controls.Add(this.btnWeiCaiSe);
            this.flowLayoutPanel4.Controls.Add(this.label19);
            this.flowLayoutPanel4.Controls.Add(this.trackBar_grayLevel);
            this.flowLayoutPanel4.Controls.Add(this.textBox_showGrayLevel);
            this.flowLayoutPanel4.Controls.Add(this.btn_GrayLevel);
            this.flowLayoutPanel4.Location = new System.Drawing.Point(593, 708);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(490, 108);
            this.flowLayoutPanel4.TabIndex = 56;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("宋体", 12F);
            this.label18.Location = new System.Drawing.Point(3, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(109, 20);
            this.label18.TabIndex = 27;
            this.label18.Text = "伪彩色处理";
            // 
            // comboBox_WeiCaiSeCollect
            // 
            this.comboBox_WeiCaiSeCollect.AutoCompleteCustomSource.AddRange(new string[] {
            "红",
            "绿",
            "蓝"});
            this.comboBox_WeiCaiSeCollect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_WeiCaiSeCollect.Font = new System.Drawing.Font("宋体", 12F);
            this.comboBox_WeiCaiSeCollect.FormattingEnabled = true;
            this.comboBox_WeiCaiSeCollect.Location = new System.Drawing.Point(118, 3);
            this.comboBox_WeiCaiSeCollect.Name = "comboBox_WeiCaiSeCollect";
            this.comboBox_WeiCaiSeCollect.Size = new System.Drawing.Size(194, 28);
            this.comboBox_WeiCaiSeCollect.TabIndex = 28;
            // 
            // btnWeiCaiSe
            // 
            this.btnWeiCaiSe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnWeiCaiSe.BackgroundImage")));
            this.btnWeiCaiSe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWeiCaiSe.FlatAppearance.BorderSize = 0;
            this.btnWeiCaiSe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWeiCaiSe.Location = new System.Drawing.Point(318, 3);
            this.btnWeiCaiSe.Name = "btnWeiCaiSe";
            this.btnWeiCaiSe.Size = new System.Drawing.Size(101, 41);
            this.btnWeiCaiSe.TabIndex = 58;
            this.btnWeiCaiSe.UseVisualStyleBackColor = true;
            this.btnWeiCaiSe.Click += new System.EventHandler(this.btnWeiCaiSe_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("宋体", 12F);
            this.label19.Location = new System.Drawing.Point(3, 47);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 20);
            this.label19.TabIndex = 59;
            this.label19.Text = "灰度分层法";
            // 
            // trackBar_grayLevel
            // 
            this.trackBar_grayLevel.Location = new System.Drawing.Point(118, 50);
            this.trackBar_grayLevel.Maximum = 255;
            this.trackBar_grayLevel.Name = "trackBar_grayLevel";
            this.trackBar_grayLevel.Size = new System.Drawing.Size(158, 56);
            this.trackBar_grayLevel.TabIndex = 58;
            this.trackBar_grayLevel.TabStop = false;
            this.trackBar_grayLevel.Scroll += new System.EventHandler(this.trackBar_grayLevel_Scroll);
            // 
            // textBox_showGrayLevel
            // 
            this.textBox_showGrayLevel.Location = new System.Drawing.Point(282, 50);
            this.textBox_showGrayLevel.Name = "textBox_showGrayLevel";
            this.textBox_showGrayLevel.Size = new System.Drawing.Size(50, 25);
            this.textBox_showGrayLevel.TabIndex = 58;
            // 
            // btn_GrayLevel
            // 
            this.btn_GrayLevel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_GrayLevel.BackgroundImage")));
            this.btn_GrayLevel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_GrayLevel.FlatAppearance.BorderSize = 0;
            this.btn_GrayLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_GrayLevel.Location = new System.Drawing.Point(338, 50);
            this.btn_GrayLevel.Name = "btn_GrayLevel";
            this.btn_GrayLevel.Size = new System.Drawing.Size(101, 41);
            this.btn_GrayLevel.TabIndex = 60;
            this.btn_GrayLevel.UseVisualStyleBackColor = true;
            this.btn_GrayLevel.Click += new System.EventHandler(this.btn_GrayLevel_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1418, 991);
            this.Controls.Add(this.flowLayoutPanel4);
            this.Controls.Add(this.btnSpinadjust);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.textBox_showSpin);
            this.Controls.Add(this.trackBar_spin);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btn_magnify);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.btnColoradjust);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox_colorCollect);
            this.Controls.Add(this.btn_hsi);
            this.Controls.Add(this.btnContrastAdjust);
            this.Controls.Add(this.textBox_showContrast);
            this.Controls.Add(this.trackBar_contrast);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_showBrightness);
            this.Controls.Add(this.btnBrightnessadjust);
            this.Controls.Add(this.trackBar_brightness);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_restore);
            this.Controls.Add(this.btn_gray);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.pictureBox_show);
            this.Controls.Add(this.btn_open);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "Form1";
            this.ShowInTaskbar = false;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_binary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_impulseNoise)).EndInit();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_RandomNoise)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_brightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_contrast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_spin)).EndInit();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_grayLevel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_open;
        private System.Windows.Forms.PictureBox pictureBox_show;
        //private System.Windows.Forms.Button button2;
        private myButton button2;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btn_gray;
        private System.Windows.Forms.Button btn_restore;
        private System.Windows.Forms.Button btn_hsi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar trackBar_binary;
        private System.Windows.Forms.TextBox textBox_showBinary;
        private System.Windows.Forms.Button btnBinaryadjust;
        private System.Windows.Forms.ComboBox comboBox_colorCollect;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnColoradjust;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_smoothCollect;
        private System.Windows.Forms.Button btnSmoothadjust;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox_sharpeningCollect;
        private System.Windows.Forms.Button btnSharpeningadjust;
        private System.Windows.Forms.ComboBox comboBox_binaryChangeCollect;
        private System.Windows.Forms.Button btnBinaryChangeadjust;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnGaussianadjust;
        private System.Windows.Forms.TextBox textBox_showImpulseNoise;
        private System.Windows.Forms.TrackBar trackBar_impulseNoise;
        private System.Windows.Forms.Button btnImpulseadjust;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Button btn_magnify;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar trackBar_brightness;
        private System.Windows.Forms.Button btnBrightnessadjust;
        private System.Windows.Forms.TextBox textBox_showBrightness;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBar_contrast;
        private System.Windows.Forms.TextBox textBox_showContrast;
        private System.Windows.Forms.Button btnContrastAdjust;
        private System.Windows.Forms.Button btnSpinadjust;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TrackBar trackBar_spin;
        private System.Windows.Forms.TextBox textBox_showSpin;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TrackBar trackBar_RandomNoise;
        private System.Windows.Forms.TextBox textBox_showRandomNoise;
        private System.Windows.Forms.Button btnRandomadjust;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_gaussianAvg;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_gaussianVariance;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox_structureElementValue;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox_structureElementSelect;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox_picCategory;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btn_edgeFillOrigin;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox_WeiCaiSeCollect;
        private System.Windows.Forms.Button btnWeiCaiSe;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TrackBar trackBar_grayLevel;
        private System.Windows.Forms.TextBox textBox_showGrayLevel;
        private System.Windows.Forms.Button btn_GrayLevel;
    }



    public class myButton : System.Windows.Forms.Button
    {
        private Color enterForeColor = Color.White;
        private Color leftForeColor = Color.Black;
        private bool Isleft = true;


        private int radius;//半径 
        public int Radius
        {
            set
            {
                radius = value;
                this.Invalidate();
            }
            get
            {
                return radius;
            }
        }


        public bool IsLEFT
        {
            get { return Isleft; }
            set
            {
                this.Isleft = value;
            }
        }

        public Color EnterForeColor
        {
            get { return enterForeColor; }
            set
            {
                this.enterForeColor = value;
                this.ForeColor = value;
            }
        }
        public Color LeftForeColor
        {
            get { return leftForeColor; }
            set
            {
                this.leftForeColor = value;
                this.ForeColor = value;
            }
        }
        [DefaultValue(typeof(Color), "51, 161, 224")]
        //  [DefaultValue(typeof(Color), "220, 80, 80")]


        //  [DefaultValue(typeof(Color), "251, 161, 0")]
        protected override void OnMouseEnter(EventArgs e)//鼠标进入时
        {
            base.OnMouseEnter(e);
            this.ForeColor = this.EnterForeColor;
        }
        protected override void OnMouseLeave(EventArgs e)//鼠标离开
        {
            base.OnMouseLeave(e);
            this.ForeColor = this.LeftForeColor;
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);
            base.OnPaintBackground(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
            Rectangle rect = new Rectangle(0, 0, this.Width, this.Height);
            var path = GetRoundedRectPath(rect, radius);
            this.Region = new Region(path);

            Color baseColor = this.BackColor;

            using (SolidBrush b = new SolidBrush(baseColor))
            {
                e.Graphics.FillPath(b, path);
                System.Drawing.Font fo = new System.Drawing.Font(this.Font.Name, this.Font.Size);
                Brush brush = new SolidBrush(this.ForeColor);
                StringFormat gs = new StringFormat();
                gs.Alignment = StringAlignment.Center; //居中
                gs.LineAlignment = StringAlignment.Center;//垂直居中
                e.Graphics.DrawString(this.Text, fo, brush, rect, gs);
            }

        }
        private GraphicsPath RectPath(Rectangle re)
        {
            GraphicsPath path = new GraphicsPath();
            Point[] ps = new Point[4];
            ps[0] = new Point(this.Width / 5, this.Height / 5);
            ps[1] = new Point(4 * this.Width / 5, this.Height / 5);
            ps[2] = new Point(this.Width / 5, 4 * this.Height / 5);
            ps[3] = new Point(4 * this.Width / 5, 4 * this.Height / 5);
            path.AddLines(ps);
            path.CloseFigure();

            return path;
        }
        private GraphicsPath GetRoundedRectPath(Rectangle rect, int radius)
        {
            int diameter = radius;
            Rectangle arcRect = new Rectangle(rect.Location, new System.Drawing.Size(diameter, diameter));
            GraphicsPath path = new GraphicsPath();
            path.AddArc(arcRect, 180, 90);
            arcRect.X = rect.Right - diameter;
            path.AddArc(arcRect, 270, 90);
            arcRect.Y = rect.Bottom - diameter;
            path.AddArc(arcRect, 0, 90);
            arcRect.X = rect.Left;
            path.AddArc(arcRect, 90, 90);
            path.CloseFigure();
            return path;
        }

    }


}


