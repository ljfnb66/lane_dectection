﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imageIdentification
{
    public partial class imageZoom : Form
    {

        private Image originalImage; // 原始图像

        int count = 0;

        private int currentWidth; // 当前图像宽度
        private int currentHeight; // 当前图像高度

        public imageZoom()
        {
            InitializeComponent();

            //捕捉滚轮事件
            //this.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseWheel);
            this.btn_bilinearityInterpolation.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseWheel);
            //this.pictureBox.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseWheel);



            //图像放大 的按钮按下恢复事件
            this.btn_magnify.MouseDown += new MouseEventHandler(btn_magnify_MouseDown);
            this.btn_magnify.MouseUp += new MouseEventHandler(btn_magnify_MouseUp);

            //图像缩小 的按钮按下恢复事件
            this.btn_reduce.MouseDown += new MouseEventHandler(btn_reduce_MouseDown);
            this.btn_reduce.MouseUp += new MouseEventHandler(btn_reduce_MouseUp);




        }

        //滚轮滚动实现图像的缩放
        private void panel1_MouseWheel(object sender, MouseEventArgs e)
        {
            if (Control.ModifierKeys == Keys.Control)
            {
                float fZoomFactor = 1.2f;      // 缩放因子
                int iOriginCentorX = (this.btn_bilinearityInterpolation.Width / 2 - this.pictureBox.Left);      //缩放前
                int iOriginCentorY = (this.btn_bilinearityInterpolation.Height / 2 - this.pictureBox.Top);

                //防止无限制的缩放
                if ((this.pictureBox.Width < 200 && e.Delta < 0) || (this.pictureBox.Width > 10000 && e.Delta > 0))
                    return;

                //鼠标滚轮向上滚动，进行放大操作
                if (e.Delta > 0)
                {
                    //缩放后的picture box的大小。
                    int iNewWidth = (int)(fZoomFactor * this.pictureBox.Width);
                    int iNewHeight = (int)(fZoomFactor * this.pictureBox.Height);

                    //定义新的Bitmap；
                    Bitmap BitNewImg = new Bitmap(iNewWidth, iNewHeight);
                    //定义对BitNewImg的绘制方法；
                    Graphics graph = Graphics.FromImage(BitNewImg);
                    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Bilinear;
                    //用原始图像绘制新图像；
                    graph.DrawImage((Bitmap)this.pictureBox.Image, new Rectangle(0, 0, iNewWidth, iNewHeight),
                        new Rectangle(0, 0, this.pictureBox.Width, this.pictureBox.Height), GraphicsUnit.Pixel);
                    //缩放后的中心点距离picture box左上角的距离。
                    int iNewCentorX = (int)(iOriginCentorX * fZoomFactor);
                    int iNewCentorY = (int)(iOriginCentorY * fZoomFactor);

                    this.pictureBox.Image = BitNewImg;
                    this.pictureBox.Width = this.pictureBox.Image.Width;
                    this.pictureBox.Height = this.pictureBox.Image.Height;
                    //缩放后的滚轮的位置。
                    this.btn_bilinearityInterpolation.AutoScrollPosition = new Point((int)(iNewCentorX - this.btn_bilinearityInterpolation.Width / 2),
                        (int)(iNewCentorY - this.btn_bilinearityInterpolation.Height / 2 + e.Delta));

                    graph.Dispose();
                }
                else
                {
                    int iNewWidth = (int)(this.pictureBox.Width / fZoomFactor);
                    int iNewHeight = (int)(this.pictureBox.Height / fZoomFactor);

                    Bitmap BitNewImg = new Bitmap(iNewWidth, iNewHeight);
                    //定义对BitNewImg的绘制方法；
                    Graphics graph = Graphics.FromImage(BitNewImg);
                    graph.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Bilinear;
                    //用原始图像绘制新图像；
                    graph.DrawImage((Bitmap)this.pictureBox.Image, new Rectangle(0, 0, iNewWidth, iNewHeight),
                        new Rectangle(0, 0, this.pictureBox.Width, this.pictureBox.Height), GraphicsUnit.Pixel);

                    this.pictureBox.Image = BitNewImg;
                    this.pictureBox.Width = this.pictureBox.Image.Width;
                    this.pictureBox.Height = this.pictureBox.Image.Height;

                    int iNewCentorX = (int)(iOriginCentorX / fZoomFactor);
                    int iNewCentorY = (int)(iOriginCentorY / fZoomFactor);

                    this.btn_bilinearityInterpolation.AutoScrollPosition = new Point((int)(iNewCentorX - this.btn_bilinearityInterpolation.Width / 2),
                        (int)(iNewCentorY - this.btn_bilinearityInterpolation.Height / 2 + e.Delta));
                }
            }
        }

        //public void panel1_MouseWheel(object sender, MouseEventArgs e)
        //{
        //    double orignZoom = 1.0 * this.panel1.Width;//原始大小
        //    double changeZoom;
        //    //通过Control.ModifierKeys属性检查是否按下了Ctrl键。只有在按下Ctrl键的情况下才会进行缩放操作。
        //    if (Control.ModifierKeys == Keys.Control)
        //    {
        //        float fZoomFactor = 1.2f;      // 缩放因子
        //        //图片在缩放之前的中心点相对于panel1的左上角的坐标偏移量。
        //        int iOriginCentorX = (this.panel1.Width / 2 - this.pictureBox.Left);//缩放前
        //        int iOriginCentorY = (this.panel1.Height / 2 - this.pictureBox.Top);

        //        //防止无限制的缩放
        //        //通过判断pictureBox的宽度是否小于200且鼠标滚轮向下滚动，或者宽度是否大于10000且鼠标滚轮向上滚动，来防止无限制的缩放。
        //        if ((this.pictureBox.Width < 200 && e.Delta < 0) || (this.pictureBox.Width > 10000 && e.Delta > 0))
        //            return;

        //        //鼠标滚轮向上滚动，进行放大操作
        //        if (e.Delta > 0)
        //        {
        //            //缩放后的picture box的大小。
        //            this.pictureBox.Width = (int)(fZoomFactor * this.pictureBox.Width);
        //            this.pictureBox.Height = (int)(fZoomFactor * this.pictureBox.Height);
        //            //缩放后的中心点距离picture box左上角的距离。
        //            int iNewCentorX = (int)(iOriginCentorX * fZoomFactor);
        //            int iNewCentorY = (int)(iOriginCentorY * fZoomFactor);

        //            changeZoom = 1.0 * panel1.Width;
        //            textBox_showZoomProportion.Text = (1.0 * (changeZoom / orignZoom)).ToString();

        //            //缩放后的滚轮的位置。
        //            this.panel1.AutoScrollPosition = new Point((int)(iNewCentorX - this.panel1.Width / 2),
        //                (int)(iNewCentorY - this.panel1.Height / 2 + e.Delta));

        //        }
        //        else
        //        {
        //            this.pictureBox.Width = (int)(this.pictureBox.Width / fZoomFactor);
        //            this.pictureBox.Height = (int)(this.pictureBox.Height / fZoomFactor);

        //            int iNewCentorX = (int)(iOriginCentorX / fZoomFactor);
        //            int iNewCentorY = (int)(iOriginCentorY / fZoomFactor);

        //            changeZoom = 1.0 * panel1.Width;
        //            textBox_showZoomProportion.Text = (1.0 * (changeZoom / orignZoom)).ToString();

        //            this.panel1.AutoScrollPosition = new Point((int)(iNewCentorX - this.panel1.Width / 2),
        //                (int)(iNewCentorY - this.panel1.Height / 2 + e.Delta));
        //        }


        //    }
        //}

        //放大按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_magnify_Click(object sender, EventArgs e)
        {


        }
        private void btn_magnify_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_magnify.BackgroundImage = new Bitmap("D:\\AllFile\\桌面\\计算机视觉\\btn_img\\magnify_glass_press.png");
        }
        private void btn_magnify_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_magnify.BackgroundImage = new Bitmap("D:\\AllFile\\桌面\\计算机视觉\\btn_img\\magnify_glass.png");
        }

        //缩小按钮？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_reduce_Click(object sender, EventArgs e)
        {
            count++;
            Image originalImage = pictureBox.Image; // 原始图像

            int newWidth = (int)(pictureBox.Width * 0.95);
            int newHeight = (int)(pictureBox.Height * 0.95);

            Image resizedImage = ShrinkImage(originalImage, newWidth, newHeight); ; // 缩小后的图像
            pictureBox.Image = resizedImage;

            int y = count * 5;
            textBox_showZoomProportion.Text = (100 - y).ToString() + "%";


        }
        private void btn_reduce_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btn_reduce.BackgroundImage = new Bitmap("D:\\AllFile\\桌面\\计算机视觉\\btn_img\\reduce_glass_press.png");
        }
        private void btn_reduce_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时恢复按钮的原始颜色
            btn_reduce.BackgroundImage = new Bitmap("D:\\AllFile\\桌面\\计算机视觉\\btn_img\\reduce_glass.png");
        }

        private Image ShrinkImage(Image originalImage, int newWidth, int newHeight)
        {
            Bitmap resizedBitmap = new Bitmap(newWidth, newHeight);
            using (Graphics graphics = Graphics.FromImage(resizedBitmap))
            {
                graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                graphics.DrawImage(originalImage, 0, 0, newWidth, newHeight);
            }
            return resizedBitmap;
        }

        //按比例缩小按钮，缩小过程中会抛弃像素点？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void button1_Click(object sender, EventArgs e)
        {
            double k = 1.05; //定义图像缩小的倍数
            count++;
            Bitmap bt1 = new Bitmap(pictureBox.Image);
            Bitmap bt2 = new Bitmap((int)(pictureBox.Width / k), (int)(pictureBox.Height / k));
            int Red, Green, Blue;
            for (int i = 0; i < bt1.Width - 1; i++)
            {
                for (int j = 0; j < bt1.Height - 1; j++)
                {
                    Red = bt1.GetPixel(i, j).R;
                    Green = bt1.GetPixel(i, j).G;
                    Blue = bt1.GetPixel(i, j).B;
                    bt2.SetPixel((int)(i / k), (int)(j / k), Color.FromArgb(Red, Green, Blue));
                }
                pictureBox.Refresh();//另外建立了一个图片框用于显示处理后的图像
                pictureBox.Image = bt2;
            }

            int y = count * 5;
            textBox_showZoomProportion.Text = (100 - y).ToString() + "%";
        }

        //最邻近插值？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_nearestInterpolation_Click(object sender, EventArgs e)
        {
            // 计算放大后的图像大小
            int newWidth = (int)(pictureBox.Width * 1.05);
            int newHeight = (int)(pictureBox.Height * 1.05);

            // 创建新的Bitmap对象
            Bitmap newImage = new Bitmap(newWidth, newHeight);

            // 最近邻插值
            for (int y = 0; y < newHeight; y++)
            {
                for (int x = 0; x < newWidth; x++)
                {
                    // 计算原始图像中对应位置
                    int sourceX = (int)(x / 1.05);
                    int sourceY = (int)(y / 1.05);

                    // 获取最近邻像素值
                    Color pixel = ((Bitmap)pictureBox.Image).GetPixel(sourceX, sourceY);

                    // 设置放大后图像像素值
                    newImage.SetPixel(x, y, pixel);
                }
            }

            count++;
            int a = count * 5;
            textBox_showZoomProportion.Text = (100 + a).ToString() + "%";

            // 更新pictureBox的图像和大小
            pictureBox.Image = newImage;
            pictureBox.Width = newWidth;
            pictureBox.Height = newHeight;

        }

        //双线性插值？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_bilinearityPolation_Click(object sender, EventArgs e)
        {
            // 计算放大后的图像大小
            int newWidth = (int)(pictureBox.Width * 1.05);
            int newHeight = (int)(pictureBox.Height * 1.05);

            // 创建新的Bitmap对象
            Bitmap newImage = new Bitmap(newWidth, newHeight);

            // 双线性插值
            for (int y = 0; y < newHeight - 1; y++)
            {
                for (int x = 0; x < newWidth - 1; x++)
                {
                    // 计算原始图像中对应位置的浮点坐标
                    float sourceX = x / 1.05f;
                    float sourceY = y / 1.05f;

                    // 计算四个最近邻像素的坐标
                    int x1 = (int)Math.Floor(sourceX);
                    int y1 = (int)Math.Floor(sourceY);
                    int x2 = x1 + 1;
                    int y2 = y1 + 1;

                    // 获取四个最近邻像素的颜色
                    Color pixel1 = ((Bitmap)pictureBox.Image).GetPixel(x1, y1);
                    Color pixel2 = ((Bitmap)pictureBox.Image).GetPixel(x2, y1);
                    Color pixel3 = ((Bitmap)pictureBox.Image).GetPixel(x1, y2);
                    Color pixel4 = ((Bitmap)pictureBox.Image).GetPixel(x2, y2);

                    // 计算插值权重
                    float weightX = sourceX - x1;
                    float weightY = sourceY - y1;

                    // 根据权重进行双线性插值计算
                    Color interpolatedPixel = InterpolateBilinear(pixel1, pixel2, pixel3, pixel4, weightX, weightY);

                    // 设置放大后图像的像素值
                    newImage.SetPixel(x, y, interpolatedPixel);
                }
            }

            count++;
            int a = count * 5;
            textBox_showZoomProportion.Text = (100 + a).ToString() + "%";

            // 更新pictureBox的图像和大小
            pictureBox.Image = newImage;
            pictureBox.Width = newWidth;
            pictureBox.Height = newHeight;
        }
        // 双线性插值计算
        private Color InterpolateBilinear(Color c1, Color c2, Color c3, Color c4, float weightX, float weightY)
        {
            int red = (int)(c1.R * (1 - weightX) * (1 - weightY) +
                            c2.R * weightX * (1 - weightY) +
                            c3.R * (1 - weightX) * weightY +
                            c4.R * weightX * weightY);

            int green = (int)(c1.G * (1 - weightX) * (1 - weightY) +
                              c2.G * weightX * (1 - weightY) +
                              c3.G * (1 - weightX) * weightY +
                              c4.G * weightX * weightY);

            int blue = (int)(c1.B * (1 - weightX) * (1 - weightY) +
                             c2.B * weightX * (1 - weightY) +
                             c3.B * (1 - weightX) * weightY +
                             c4.B * weightX * weightY);

            return Color.FromArgb(red, green, blue);
        }

        //双三次插值？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？？
        private void btn_threePolation_Click(object sender, EventArgs e)
        {
            // 计算放大后的图像大小
            int newWidth = (int)(pictureBox.Width * 1.05);
            int newHeight = (int)(pictureBox.Height * 1.05);

            // 创建新的Bitmap对象
            Bitmap newImage = new Bitmap(newWidth, newHeight);

            // 双三次插值
            for (int y = 0; y < newHeight; y++)
            {
                for (int x = 0; x < newWidth; x++)
                {
                    // 计算原始图像中对应位置的浮点坐标
                    float sourceX = x / 1.05f;
                    float sourceY = y / 1.05f;

                    // 获取双三次插值像素值
                    Color interpolatedPixel = InterpolateBicubic((Bitmap)pictureBox.Image, sourceX, sourceY);

                    // 设置放大后图像的像素值
                    newImage.SetPixel(x, y, interpolatedPixel);
                }
            }
            count++;
            int a = count * 5;
            textBox_showZoomProportion.Text = (100 + a).ToString() + "%";

            // 更新pictureBox的图像和大小
            pictureBox.Image = newImage;
            pictureBox.Width = newWidth;
            pictureBox.Height = newHeight;
        }

        // 双三次插值计算
        private Color InterpolateBicubic(Bitmap image, float x, float y)
        {
            int intX = (int)x;
            int intY = (int)y;
            float fractionX = x - intX;
            float fractionY = y - intY;

            Color[,] pixels = new Color[4, 4];

            // 收集16个最近邻像素的颜色
            for (int offsetY = -1; offsetY <= 2; offsetY++)
            {
                for (int offsetX = -1; offsetX <= 2; offsetX++)
                {
                    int pixelX = Clamp(intX + offsetX, 0, image.Width - 1);
                    int pixelY = Clamp(intY + offsetY, 0, image.Height - 1);
                    pixels[offsetX + 1, offsetY + 1] = image.GetPixel(pixelX, pixelY);
                }
            }

            // 计算权重
            float[] weightsX = CalculateWeights(fractionX);
            float[] weightsY = CalculateWeights(fractionY);

            // 插值计算
            float red = 0f;
            float green = 0f;
            float blue = 0f;

            for (int offsetY = 0; offsetY < 4; offsetY++)
            {
                for (int offsetX = 0; offsetX < 4; offsetX++)
                {
                    float weight = weightsX[offsetX] * weightsY[offsetY];
                    red += pixels[offsetX, offsetY].R * weight;
                    green += pixels[offsetX, offsetY].G * weight;
                    blue += pixels[offsetX, offsetY].B * weight;
                }
            }

            return Color.FromArgb(Clamp((int)red, 0, 255), Clamp((int)green, 0, 255), Clamp((int)blue, 0, 255));
        }

        // 计算权重
        private float[] CalculateWeights(float t)
        {
            float[] weights = new float[4];

            float t2 = t * t;
            float t3 = t2 * t;

            weights[0] = -0.5f * t3 + t2 - 0.5f * t;
            weights[1] = 1.5f * t3 - 2.5f * t2 + 1.0f;
            weights[2] = -1.5f * t3 + 2.0f * t2 + 0.5f * t;
            weights[3] = 0.5f * t3 - 0.5f * t2;

            return weights;
        }

        // 限制值在指定范围内
        private int Clamp(int value, int minValue, int maxValue)
        {
            return Math.Max(minValue, Math.Min(value, maxValue));
        }

    }
}
