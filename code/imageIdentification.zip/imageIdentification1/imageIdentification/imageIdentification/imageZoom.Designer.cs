﻿using System.Runtime.CompilerServices;

namespace imageIdentification
{
    partial class imageZoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(imageZoom));
            this.btn_bilinearityInterpolation = new System.Windows.Forms.Panel();
            this.btn_threePolation = new System.Windows.Forms.Button();
            this.btn_bilinearityPolation = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_nearestInterpolation = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_showZoomProportion = new System.Windows.Forms.TextBox();
            this.btn_reduce = new System.Windows.Forms.Button();
            this.btn_magnify = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.btn_bilinearityInterpolation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_bilinearityInterpolation
            // 
            this.btn_bilinearityInterpolation.AutoScroll = true;
            this.btn_bilinearityInterpolation.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_bilinearityInterpolation.Controls.Add(this.btn_threePolation);
            this.btn_bilinearityInterpolation.Controls.Add(this.btn_bilinearityPolation);
            this.btn_bilinearityInterpolation.Controls.Add(this.label2);
            this.btn_bilinearityInterpolation.Controls.Add(this.label1);
            this.btn_bilinearityInterpolation.Controls.Add(this.btn_nearestInterpolation);
            this.btn_bilinearityInterpolation.Controls.Add(this.button1);
            this.btn_bilinearityInterpolation.Controls.Add(this.textBox_showZoomProportion);
            this.btn_bilinearityInterpolation.Controls.Add(this.btn_reduce);
            this.btn_bilinearityInterpolation.Controls.Add(this.btn_magnify);
            this.btn_bilinearityInterpolation.Controls.Add(this.pictureBox);
            this.btn_bilinearityInterpolation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_bilinearityInterpolation.Location = new System.Drawing.Point(0, 0);
            this.btn_bilinearityInterpolation.Name = "btn_bilinearityInterpolation";
            this.btn_bilinearityInterpolation.Size = new System.Drawing.Size(935, 742);
            this.btn_bilinearityInterpolation.TabIndex = 0;
            // 
            // btn_threePolation
            // 
            this.btn_threePolation.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_threePolation.Location = new System.Drawing.Point(719, 698);
            this.btn_threePolation.Name = "btn_threePolation";
            this.btn_threePolation.Size = new System.Drawing.Size(141, 41);
            this.btn_threePolation.TabIndex = 45;
            this.btn_threePolation.Text = "双三次插值";
            this.btn_threePolation.UseVisualStyleBackColor = true;
            this.btn_threePolation.Click += new System.EventHandler(this.btn_threePolation_Click);
            // 
            // btn_bilinearityPolation
            // 
            this.btn_bilinearityPolation.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_bilinearityPolation.Location = new System.Drawing.Point(557, 698);
            this.btn_bilinearityPolation.Name = "btn_bilinearityPolation";
            this.btn_bilinearityPolation.Size = new System.Drawing.Size(141, 41);
            this.btn_bilinearityPolation.TabIndex = 44;
            this.btn_bilinearityPolation.Text = "双线性插值";
            this.btn_bilinearityPolation.UseVisualStyleBackColor = true;
            this.btn_bilinearityPolation.Click += new System.EventHandler(this.btn_bilinearityPolation_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F);
            this.label2.Location = new System.Drawing.Point(285, 708);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 43;
            this.label2.Text = "图像放大：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(285, 652);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 20);
            this.label1.TabIndex = 42;
            this.label1.Text = "图像缩小：";
            // 
            // btn_nearestInterpolation
            // 
            this.btn_nearestInterpolation.Font = new System.Drawing.Font("宋体", 12F);
            this.btn_nearestInterpolation.Location = new System.Drawing.Point(400, 698);
            this.btn_nearestInterpolation.Name = "btn_nearestInterpolation";
            this.btn_nearestInterpolation.Size = new System.Drawing.Size(141, 41);
            this.btn_nearestInterpolation.TabIndex = 41;
            this.btn_nearestInterpolation.Text = "最邻近插值";
            this.btn_nearestInterpolation.UseVisualStyleBackColor = true;
            this.btn_nearestInterpolation.Click += new System.EventHandler(this.btn_nearestInterpolation_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("宋体", 12F);
            this.button1.Location = new System.Drawing.Point(400, 642);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 41);
            this.button1.TabIndex = 40;
            this.button1.Text = "按比例缩小";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_showZoomProportion
            // 
            this.textBox_showZoomProportion.Location = new System.Drawing.Point(124, 698);
            this.textBox_showZoomProportion.Name = "textBox_showZoomProportion";
            this.textBox_showZoomProportion.Size = new System.Drawing.Size(51, 25);
            this.textBox_showZoomProportion.TabIndex = 38;
            // 
            // btn_reduce
            // 
            this.btn_reduce.BackColor = System.Drawing.Color.Transparent;
            this.btn_reduce.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_reduce.BackgroundImage")));
            this.btn_reduce.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_reduce.FlatAppearance.BorderSize = 0;
            this.btn_reduce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_reduce.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_reduce.Location = new System.Drawing.Point(206, 687);
            this.btn_reduce.Name = "btn_reduce";
            this.btn_reduce.Size = new System.Drawing.Size(42, 41);
            this.btn_reduce.TabIndex = 4;
            this.btn_reduce.UseVisualStyleBackColor = false;
            this.btn_reduce.Click += new System.EventHandler(this.btn_reduce_Click);
            // 
            // btn_magnify
            // 
            this.btn_magnify.BackColor = System.Drawing.Color.Transparent;
            this.btn_magnify.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_magnify.BackgroundImage")));
            this.btn_magnify.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_magnify.FlatAppearance.BorderSize = 0;
            this.btn_magnify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_magnify.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_magnify.Location = new System.Drawing.Point(45, 687);
            this.btn_magnify.Name = "btn_magnify";
            this.btn_magnify.Size = new System.Drawing.Size(51, 41);
            this.btn_magnify.TabIndex = 3;
            this.btn_magnify.UseVisualStyleBackColor = false;
            this.btn_magnify.Click += new System.EventHandler(this.btn_magnify_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(397, 354);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // imageZoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 742);
            this.Controls.Add(this.btn_bilinearityInterpolation);
            this.Name = "imageZoom";
            this.Text = "imageZoom";
            this.btn_bilinearityInterpolation.ResumeLayout(false);
            this.btn_bilinearityInterpolation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel btn_bilinearityInterpolation;
       

        //private System.Windows.Forms.PictureBox pictureBox;
        public System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Button btn_reduce;
        private System.Windows.Forms.Button btn_magnify;
        private System.Windows.Forms.TextBox textBox_showZoomProportion;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_bilinearityPolation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_nearestInterpolation;
        private System.Windows.Forms.Button btn_threePolation;
    }

}