﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using imageIdentification;

namespace imageIdentification
{
    public partial class Form_HSI : Form
    {

        //Form_HSI定义的临时变量，为了接收主界面中的原始图像
        public static PictureBox form_hsi_image_temp = new PictureBox();

        public int valueH = new int();
        public int valueS = new int();
        public int valueI = new int();

        public Form_HSI()
        {
            InitializeComponent();


            //图像HSI调节的按钮按下恢复事件
            this.btnBrightnessadjust.MouseDown += new MouseEventHandler(btnBrightnessadjust_MouseDown);
            this.btnBrightnessadjust.MouseUp += new MouseEventHandler(btnBrightnessadjust_MouseUp);
        }

 

        //HSI调节按钮的确认点击事件
        private void btnBrightnessadjust_Click(object sender, EventArgs e)
        {
            valueH = trackBar_H.Value;
            valueS = trackBar_S.Value;
            valueI = trackBar_I.Value;
            this.Close();//关闭这个子窗口
        }
        private void btnBrightnessadjust_MouseUp(object sender, MouseEventArgs e)
        {
            // 当鼠标松开时改变按钮颜色
            btnBrightnessadjust.BackgroundImage = new Bitmap("D:\\AllFile\\桌面\\计算机视觉\\btn_img\\btn_confirm.png");
        }


        private void btnBrightnessadjust_MouseDown(object sender, MouseEventArgs e)
        {
            // 当鼠标按下时改变按钮颜色
            btnBrightnessadjust.BackgroundImage = new Bitmap("D:\\AllFile\\桌面\\计算机视觉\\btn_img\\btn_confirm_press.png");
        }


        private void trackBar_H_Scroll(object sender, EventArgs e)
        {
            //拉动 色调 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示
            textBox_valueH.Text = trackBar_H.Value.ToString();
        }

        private void trackBar_S_Scroll(object sender, EventArgs e)
        {

            //拉动 饱和度 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示
            textBox_valueS.Text = trackBar_S.Value.ToString();
        }

        private void trackBar_I_Scroll(object sender, EventArgs e)
        {
            //拉动 强度 滑杆后，滑杆的值改变，将滑杆的值在文本框中显示
            textBox_valueI.Text = trackBar_I.Value.ToString();
        }




    }
}
