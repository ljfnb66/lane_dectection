﻿namespace imageIdentification
{
    partial class Form_HSI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_HSI));
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.trackBar_H = new System.Windows.Forms.TrackBar();
            this.textBox_valueH = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.trackBar_S = new System.Windows.Forms.TrackBar();
            this.textBox_valueS = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBar_I = new System.Windows.Forms.TrackBar();
            this.textBox_valueI = new System.Windows.Forms.TextBox();
            this.btnBrightnessadjust = new System.Windows.Forms.Button();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_H)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_I)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("黑体", 18F);
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(24, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "HSI分量调节";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel1.Controls.Add(this.label4);
            this.flowLayoutPanel1.Controls.Add(this.trackBar_H);
            this.flowLayoutPanel1.Controls.Add(this.textBox_valueH);
            this.flowLayoutPanel1.Controls.Add(this.label3);
            this.flowLayoutPanel1.Controls.Add(this.trackBar_S);
            this.flowLayoutPanel1.Controls.Add(this.textBox_valueS);
            this.flowLayoutPanel1.Controls.Add(this.label2);
            this.flowLayoutPanel1.Controls.Add(this.trackBar_I);
            this.flowLayoutPanel1.Controls.Add(this.textBox_valueI);
            this.flowLayoutPanel1.Controls.Add(this.flowLayoutPanel2);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(78, 89);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(503, 192);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 15F);
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 25);
            this.label4.TabIndex = 2;
            this.label4.Text = "H(色  调)";
            // 
            // trackBar_H
            // 
            this.trackBar_H.Location = new System.Drawing.Point(136, 3);
            this.trackBar_H.Maximum = 360;
            this.trackBar_H.Name = "trackBar_H";
            this.trackBar_H.Size = new System.Drawing.Size(222, 56);
            this.trackBar_H.TabIndex = 3;
            this.trackBar_H.Scroll += new System.EventHandler(this.trackBar_H_Scroll);
            // 
            // textBox_valueH
            // 
            this.textBox_valueH.Location = new System.Drawing.Point(364, 3);
            this.textBox_valueH.Name = "textBox_valueH";
            this.textBox_valueH.Size = new System.Drawing.Size(100, 25);
            this.textBox_valueH.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 15F);
            this.label3.Location = new System.Drawing.Point(3, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "S(饱和度)";
            // 
            // trackBar_S
            // 
            this.trackBar_S.Location = new System.Drawing.Point(135, 65);
            this.trackBar_S.Maximum = 100;
            this.trackBar_S.Name = "trackBar_S";
            this.trackBar_S.Size = new System.Drawing.Size(223, 56);
            this.trackBar_S.TabIndex = 3;
            this.trackBar_S.Scroll += new System.EventHandler(this.trackBar_S_Scroll);
            // 
            // textBox_valueS
            // 
            this.textBox_valueS.Location = new System.Drawing.Point(364, 65);
            this.textBox_valueS.Name = "textBox_valueS";
            this.textBox_valueS.Size = new System.Drawing.Size(100, 25);
            this.textBox_valueS.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 15F);
            this.label2.Location = new System.Drawing.Point(3, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "I(强  度)";
            // 
            // trackBar_I
            // 
            this.trackBar_I.Location = new System.Drawing.Point(136, 127);
            this.trackBar_I.Maximum = 100;
            this.trackBar_I.Name = "trackBar_I";
            this.trackBar_I.Size = new System.Drawing.Size(222, 56);
            this.trackBar_I.TabIndex = 3;
            this.trackBar_I.Scroll += new System.EventHandler(this.trackBar_I_Scroll);
            // 
            // textBox_valueI
            // 
            this.textBox_valueI.Location = new System.Drawing.Point(364, 127);
            this.textBox_valueI.Name = "textBox_valueI";
            this.textBox_valueI.Size = new System.Drawing.Size(100, 25);
            this.textBox_valueI.TabIndex = 4;
            // 
            // btnBrightnessadjust
            // 
            this.btnBrightnessadjust.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBrightnessadjust.BackgroundImage")));
            this.btnBrightnessadjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBrightnessadjust.FlatAppearance.BorderSize = 0;
            this.btnBrightnessadjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrightnessadjust.Location = new System.Drawing.Point(246, 308);
            this.btnBrightnessadjust.Name = "btnBrightnessadjust";
            this.btnBrightnessadjust.Size = new System.Drawing.Size(140, 59);
            this.btnBrightnessadjust.TabIndex = 9;
            this.btnBrightnessadjust.UseVisualStyleBackColor = true;
            this.btnBrightnessadjust.Click += new System.EventHandler(this.btnBrightnessadjust_Click);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 189);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel2.TabIndex = 5;
            // 
            // Form_HSI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(658, 410);
            this.Controls.Add(this.btnBrightnessadjust);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Name = "Form_HSI";
            this.Text = "Form_HSI";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_H)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_I)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar trackBar_H;
        private System.Windows.Forms.TextBox textBox_valueH;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar trackBar_S;
        private System.Windows.Forms.TextBox textBox_valueS;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBar_I;
        private System.Windows.Forms.TextBox textBox_valueI;
        private System.Windows.Forms.Button btnBrightnessadjust;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
    }
}